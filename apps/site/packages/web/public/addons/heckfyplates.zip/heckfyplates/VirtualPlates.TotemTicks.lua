local _, me = ...
local frame = CreateFrame("Frame")
local records = {}
local counts, byName = {}, {} -- reused every update
local pulses = { SPELL_DAMAGE = true, SPELL_PERIODIC_DAMAGE = true,
    SPELL_HEAL = true, SPELL_PERIODIC_HEAL = true, SPELL_ENERGIZE = true,
    SPELL_PERIODIC_ENERGIZE = true, SPELL_DISPEL = true, SPELL_MISSED = true }

local function Key(name)
    local category, key = me.ResolveFilter(name)
    if category == "totems" and me.Defaults.totemTicks.intervals[key] then return key end
end

local function Hide(data)
    if data.tickOverlay then data.tickOverlay:Hide() end
end

local function Create(data)
    local icon = data.totemIcon
    local overlay = CreateFrame("Frame", nil, icon)
    overlay:SetAllPoints(icon)
    overlay:EnableMouse(false)
    overlay.shade = overlay:CreateTexture(nil, "OVERLAY")
    overlay.shade:SetTexture("Interface\\Buttons\\WHITE8X8")
    overlay.shade:SetPoint("TOPLEFT", icon, "TOPLEFT", 0, 0)
    overlay.cooldown = CreateFrame("Cooldown", nil, overlay, "CooldownFrameTemplate")
    overlay.cooldown:SetAllPoints(icon)
    overlay.cooldown:EnableMouse(false)
    overlay.cooldown.noCooldownCount = true
    if overlay.cooldown.SetReverse then overlay.cooldown:SetReverse(true) end
    local textFrame = CreateFrame("Frame", nil, overlay)
    textFrame:SetAllPoints(icon)
    textFrame:EnableMouse(false)
    overlay.textFrame = textFrame
    overlay.text = textFrame:CreateFontString(nil, "OVERLAY")
    data.tickOverlay = overlay
end

function me.UpdateTotemTicks()
    if not me.Profile then return end
    local cfg, now = me.Profile.totemTicks, GetTime()
    wipe(counts); wipe(byName)
    for guid, record in pairs(records) do
        if now - record.seen > 600 then records[guid] = nil
        else
            if byName[record.name] then byName[record.name] = false
            elseif byName[record.name] == nil then byName[record.name] = record end
        end
    end
    for plate, data in pairs(me.PlateData) do
        if plate:IsShown() and data.name then
            local name = me.CleanName(data.name:GetText())
            counts[name] = (counts[name] or 0) + 1
        end
    end
    for plate, data in pairs(me.PlateData) do
        local name = data.name and me.CleanName(data.name:GetText())
        local key = name and Key(name)
        if not plate:IsShown() then
            data.tickStart, data.tickName = nil, nil
            Hide(data)
        elseif cfg.mode == "OFF" or not key or data.filtered or not data.totemIcon
            or not data.totemIcon:IsShown() then Hide(data)
        else
            if not data.tickOverlay then Create(data) end
            if data.tickName ~= name then data.tickName, data.tickStart = name, now end
            local record = counts[name] == 1 and byName[name] or nil
            -- 3.3.5 plates have no GUID: never associate ambiguous same-name totems.
            if record and record.key ~= key then record = nil end
            if record and record.dead then Hide(data)
            else
                local period = cfg.intervals[key]
                local start = record and record.start or data.tickStart or now
                local elapsed = math.max(0, now - start)
                local cycle = math.floor(elapsed / period)
                local fraction = (elapsed - cycle * period) / period
                local overlay = data.tickOverlay
                overlay:SetFrameLevel(data.totemIcon:GetFrameLevel() + 1)
                overlay.cooldown:SetFrameLevel(overlay:GetFrameLevel() + 1)
                overlay.textFrame:SetFrameLevel(overlay:GetFrameLevel() + 2)
                overlay:Show()
                local vertical = cfg.mode == "VERTICAL" or cfg.mode == "TEXT_VERTICAL"
                local radial = cfg.mode == "RADIAL" or cfg.mode == "TEXT_RADIAL"
                local text = cfg.mode == "TEXT" or cfg.mode == "TEXT_VERTICAL" or cfg.mode == "TEXT_RADIAL"
                overlay.shade:SetVertexColor(0, 0, 0, cfg.opacity)
                overlay.shade:SetWidth(data.totemIcon:GetWidth())
                overlay.shade:SetHeight(math.max(0.001, data.totemIcon:GetHeight() * fraction))
                if vertical then overlay.shade:Show() else overlay.shade:Hide() end
                if radial then
                    local cycleStart = start + cycle * period
                    if overlay.cycleStart ~= cycleStart or overlay.period ~= period then
                        overlay.cooldown:SetCooldown(cycleStart, period)
                        overlay.cycleStart, overlay.period = cycleStart, period
                    end
                    overlay.cooldown:SetAlpha(cfg.opacity)
                    overlay.cooldown:Show()
                else
                    overlay.cooldown:Hide()
                    overlay.cycleStart = nil
                end
                overlay.text:SetFont(STANDARD_TEXT_FONT,
                    math.min(cfg.size, math.max(4, data.totemIcon:GetWidth() / 3.5)), "OUTLINE")
                overlay.text:ClearAllPoints()
                overlay.text:SetPoint("CENTER", data.totemIcon, "CENTER", cfg.x, cfg.y)
                overlay.text:SetTextColor(1, 1, 1)
                overlay.text:SetFormattedText("%.1f", period * (1 - fraction))
                if text then overlay.text:Show() else overlay.text:Hide() end
                data.tickRemaining = period * (1 - fraction)
            end
        end
    end
end

function me.InitializeTotemTicks()
    frame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
    frame:RegisterEvent("PLAYER_ENTERING_WORLD")
    frame:SetScript("OnEvent", function(_, event, timestamp, kind,
        sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags)
        if event == "PLAYER_ENTERING_WORLD" then
            wipe(records)
            for _, data in pairs(me.PlateData) do
                data.tickStart, data.tickName = nil, nil
                Hide(data)
            end
            return
        end
        if kind == "UNIT_DIED" or kind == "UNIT_DESTROYED" then
            if records[destGUID] then records[destGUID].dead = true end
            return
        end
        local guid, name = sourceGUID, sourceName
        if kind == "SPELL_SUMMON" then guid, name = destGUID, destName
        elseif not pulses[kind] then return end
        if not guid or not name then return end
        local key = Key(name)
        if not key then return end
        local now = GetTime()
        local record = records[guid]
        -- A pulse can hit several targets; treat the batch as one event.
        if not record then
            records[guid] = { name = me.CleanName(name), key = key, start = now, seen = now }
        elseif now - record.start > 0.25 or kind == "SPELL_SUMMON" then
            record.name, record.key, record.start, record.seen, record.dead = me.CleanName(name), key, now, now, nil
        else record.seen = now end
    end)
    local elapsed = 0
    frame:SetScript("OnUpdate", function(_, delta)
        elapsed = elapsed + delta
        if elapsed >= 0.05 then elapsed = 0; me.UpdateTotemTicks() end
    end)
end
