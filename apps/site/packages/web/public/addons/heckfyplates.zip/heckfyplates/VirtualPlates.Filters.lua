local _, me = ...

me.FilterEntries = {
    { "grounding", "totems", 8177, "Grounding Totem", "Тотем заземления" },
    { "tremor", "totems", 8143, "Tremor Totem", "Тотем трепета" },
    { "earthbind", "totems", 2484, "Earthbind Totem", "Тотем оков земли" },
    { "stoneclaw", "totems", 5730, "Stoneclaw Totem", "Тотем каменного когтя" },
    { "stoneskin", "totems", 8071, "Stoneskin Totem", "Тотем каменной кожи" },
    { "strength", "totems", 8075, "Strength of Earth Totem", "Тотем силы земли" },
    { "earth_elemental_totem", "totems", 2062, "Earth Elemental Totem", "Тотем элементаля земли" },
    { "fire_elemental_totem", "totems", 2894, "Fire Elemental Totem", "Тотем элементаля огня" },
    { "searing", "totems", 3599, "Searing Totem", "Опаляющий тотем" },
    { "magma", "totems", 8190, "Magma Totem", "Тотем магмы" },
    { "fire_nova", "totems", 1535, "Fire Nova Totem", "Тотем кольца огня" },
    { "flametongue", "totems", 8227, "Flametongue Totem", "Тотем языка пламени" },
    { "totem_wrath", "totems", 30706, "Totem of Wrath", "Тотем гнева" },
    { "frost_resistance", "totems", 8181, "Frost Resistance Totem", "Тотем сопротивления льду" },
    { "healing_stream", "totems", 5394, "Healing Stream Totem", "Тотем исцеляющего потока" },
    { "mana_spring", "totems", 5675, "Mana Spring Totem", "Тотем источника маны" },
    { "mana_tide", "totems", 16190, "Mana Tide Totem", "Тотем прилива маны" },
    { "cleansing", "totems", 8170, "Cleansing Totem", "Тотем очищения" },
    { "fire_resistance", "totems", 8184, "Fire Resistance Totem", "Тотем сопротивления огню" },
    { "windfury", "totems", 8512, "Windfury Totem", "Тотем неистовства ветра" },
    { "wrath_air", "totems", 3738, "Wrath of Air Totem", "Тотем гнева воздуха" },
    { "nature_resistance", "totems", 10595, "Nature Resistance Totem", "Тотем сопротивления силам природы" },
    { "sentry", "totems", 6495, "Sentry Totem", "Сторожевой тотем" },
    { "gargoyle", "minions", 49206, "Gargoyle", "Горгулья", "Гаргулья", npc = { 27829 } },
    { "ghoul", "minions", 46584, "Ghoul", "Вурдалак", npc = { 26125 } },
    { "army", "minions", 42650, "Army of the Dead", "Армия мертвых", npc = { 24207 } },
    { "water_elemental", "minions", 31687, "Water Elemental", "Элементаль воды", npc = { 510 } },
    { "fire_elemental", "minions", 32982, "Greater Fire Elemental", "Большой элементаль огня", npc = { 15438 } },
    { "earth_elemental", "minions", 33663, "Greater Earth Elemental", "Большой элементаль земли", npc = { 15352 } },
    { "shadowfiend", "minions", 34433, "Shadowfiend", "Исчадие Тьмы", npc = { 19668 } },
    { "wolves", "minions", 51533, "Spirit Wolf", "Дух волка", npc = { 29264 } },
    { "treants", "minions", 33831, "Treant", "Древень", npc = { 1964 } },
    { "mirror", "minions", 55342, "Mirror Image", "Зеркальное изображение", npc = { 31216 } },
    { "infernal", "minions", 1122, "Infernal", "Инфернал", npc = { 89 } },
    { "doomguard", "minions", 18540, "Doomguard", "Страж ужаса", npc = { 11859 } },
    { "imp", "pets", 688, "Imp", "Бес", npc = { 416 } },
    { "voidwalker", "pets", 697, "Voidwalker", "Демон Бездны", npc = { 1860 } },
    { "succubus", "pets", 712, "Succubus", "Суккуб", npc = { 1863 } },
    { "felhunter", "pets", 691, "Felhunter", "Охотник Скверны", npc = { 417 } },
    { "felguard", "pets", 30146, "Felguard", "Страж Скверны", npc = { 17252 } },
}

local byName, byNPC, bySpell = {}, {}, {}
local learned, players = {}, {}
local filterFrame = CreateFrame("Frame")
me.Units = { "target", "focus", "mouseover", "pet", "targettarget", "targettargettarget",
    "focustarget", "focustargettarget", "mouseovertarget", "mouseovertargettarget",
    "pettarget", "pettargettarget" }
for _, group in ipairs({ { "party", 4 }, { "raid", 40 }, { "arena", 5 } }) do
    for index = 1, group[2] do
        for _, unit in ipairs({ group[1] .. index, group[1] .. index .. "target",
            group[1] .. index .. "targettarget", group[1] .. "pet" .. index,
            group[1] .. "pet" .. index .. "target" }) do
            me.Units[#me.Units + 1] = unit
        end
    end
end

-- Cleaned names are cached: the same few names are cleaned many times a second.
local cleanCache, cleanCount = {}, 0

function me.CleanName(name)
    if type(name) ~= "string" then return "" end
    local cached = cleanCache[name]
    if cached then return cached end
    local clean = name:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    clean = clean:gsub("%s+[IVX]+$", ""):gsub("%s+%d+$", "")
    clean = clean:match("^%s*(.-)%s*$")
    if cleanCount >= 2000 then wipe(cleanCache); cleanCount = 0 end
    cleanCache[name], cleanCount = clean, cleanCount + 1
    return clean
end

local function NPCID(guid)
    if type(guid) ~= "string" then return end
    local prefix = guid:sub(3, 6)
    if prefix == "F130" or prefix == "F140" or prefix == "F150" then
        return tonumber(guid:sub(7, 12), 16)
    end
end

local function Remember(name, guid, category, key)
    name = me.CleanName(name)
    if name == "" or not guid then return end
    learned[name] = learned[name] or {}
    local previous = learned[name][guid]
    if previous and not key and previous.key then
        category, key = previous.category, previous.key
    end
    if previous then
        previous.category, previous.key, previous.time = category, key, GetTime()
    else
        learned[name][guid] = { category = category, key = key, time = GetTime() }
    end
end

function me.ResolveFilter(name)
    name = me.CleanName(name)
    if players[name] and GetTime() - players[name] < 20 then return "players" end
    local records = learned[name]
    if records then
        local category, key
        for guid, record in pairs(records) do
            if GetTime() - record.time > 120 then records[guid] = nil
            elseif category and (category ~= record.category or key ~= record.key) then
                return nil -- Conflicting names cannot be associated with one plate reliably.
            else category, key = record.category, record.key end
        end
        if category then return category, key end
    end
    local entry = byName[name]
    if entry then return entry[2], entry[1] end
end

function me.ShouldShow(name)
    local filters = me.Profile.filters
    name = me.CleanName(name)
    local category, key = me.ResolveFilter(name)
    if key and type(filters.overrides[key]) == "boolean" then return filters.overrides[key] end
    if category then return filters[category] end
    -- Unknown plates may be players or renamed pets. Preserve them until identified.
    return true
end

local function ObserveUnits()
    for _, unit in ipairs(me.Units) do
        if UnitExists(unit) then
            local name, guid = UnitName(unit), UnitGUID(unit)
            if name and guid then
                name = me.CleanName(name)
                if UnitIsPlayer(unit) then
                    players[name] = GetTime()
                else
                    local id = NPCID(guid)
                    local entry = id and byNPC[id] or byName[name]
                    local category = entry and entry[2] or "npcs"
                    if not entry and UnitPlayerControlled(unit) then category = "pets" end
                    Remember(name, guid, category, entry and entry[1])
                end
            end
        end
    end
end

--- Applies filter and totem appearance to one plate. Also called the moment a plate
-- shows up or changes its name, so totems never flash as a text nameplate first.
function me.ClassifyPlate(plate, data)
    if not me.Profile or not data.name then return end
    data.classifiedName = data.name:GetText()
    local hidden = not me.ShouldShow(data.classifiedName)
    data.filtered = hidden
    -- Label first: it gives the name back before totem styling records region parents.
    if me.UpdateLabel then me.UpdateLabel(plate, data) end
    if me.StyleTotem then me.StyleTotem(plate, data) end
    if hidden then
        -- Use the unmodified frame method: visual:SetAlpha forwards to the native plate.
        me.Frame.SetAlpha(data.visual, 0)
        if data.bar then data.bar:Hide() end
    end
    -- Native targeting is owned by the client; filtered plates park their click zone off screen.
    me.UpdateClickZone(plate)
end

function me.UpdateFilters()
    if not me.Profile then return end
    ObserveUnits()
    for plate, data in pairs(me.PlateData) do
        if plate:IsShown() and data.name then me.ClassifyPlate(plate, data) end
    end
    local now = GetTime()
    for name, records in pairs(learned) do
        for guid, record in pairs(records) do
            if now - record.time > 120 then records[guid] = nil end
        end
        if not next(records) then learned[name] = nil end
    end
    for name, time in pairs(players) do
        if now - time > 20 then players[name] = nil end
    end
end

function me.InitializeFilters()
    for _, entry in ipairs(me.FilterEntries) do
        for index = 4, #entry do byName[me.CleanName(entry[index])] = entry end
        local localized = GetSpellInfo(entry[3])
        if localized then byName[me.CleanName(localized)] = entry end
        bySpell[entry[3]] = entry
        for _, id in ipairs(entry.npc or {}) do byNPC[id] = entry end
    end
    filterFrame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
    filterFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    filterFrame:SetScript("OnEvent", function(_, event, timestamp, kind,
        sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, spellID, spellName)
        if event == "PLAYER_ENTERING_WORLD" then
            wipe(learned)
            wipe(players)
            return
        end
        if kind == "UNIT_DIED" or kind == "UNIT_DESTROYED" then
            local records = learned[me.CleanName(destName)]
            if records then records[destGUID] = nil end
            return
        end
        local function Record(guid, name, flags, summon)
            if not guid or not name or not flags then return end
            if bit.band(flags, COMBATLOG_OBJECT_TYPE_PLAYER or 0x400) ~= 0 then
                players[me.CleanName(name)] = GetTime()
                return
            end
            local entry = summon or byNPC[NPCID(guid)] or byName[me.CleanName(name)]
            if entry then Remember(name, guid, entry[2], entry[1])
            elseif bit.band(flags, COMBATLOG_OBJECT_CONTROL_PLAYER or 0x100) ~= 0 then
                if bit.band(flags, COMBATLOG_OBJECT_TYPE_GUARDIAN or 0x2000) ~= 0 then
                    Remember(name, guid, "minions")
                elseif bit.band(flags, COMBATLOG_OBJECT_TYPE_PET or 0x1000) ~= 0 then
                    Remember(name, guid, "pets")
                end
            end
        end
        local summon
        if kind == "SPELL_SUMMON" then summon = bySpell[spellID] or byName[me.CleanName(spellName)] end
        Record(sourceGUID, sourceName, sourceFlags)
        Record(destGUID, destName, destFlags, summon)
    end)
    local elapsed = 0
    filterFrame:SetScript("OnUpdate", function(_, delta)
        elapsed = elapsed + delta
        if elapsed >= 0.15 then elapsed = 0; me.UpdateFilters() end
    end)
end
