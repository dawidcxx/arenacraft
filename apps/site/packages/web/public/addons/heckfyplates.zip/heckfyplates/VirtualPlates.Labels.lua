-- Name label: class name instead of the player name and arena numbers (arena1-5).
-- The native name text is never changed (every module identifies plates by it).
-- The client keeps re-showing the name, so alpha is not enough: the name is moved
-- into a hidden frame (as totem icon mode does) and our label takes its anchors.
local _, me = ...
local arenaIndex, arenaClass = {}, {}
local inArena

local function RefreshArena()
    wipe(arenaIndex); wipe(arenaClass)
    local _, instanceType = IsInInstance()
    inArena = instanceType == "arena"
    if not inArena then return end
    for index = 1, 5 do
        local unit = "arena" .. index
        local name = UnitName(unit)
        if name then
            arenaIndex[name] = index
            local _, class = UnitClass(unit)
            arenaClass[name] = class
        end
    end
end

local function Ensure(data)
    if data.labelFrame then return end
    local frame = CreateFrame("Frame", nil, data.visual)
    frame:EnableMouse(false)
    frame:SetAllPoints(data.visual)
    data.labelFrame = frame
    data.label = frame:CreateFontString(nil, "OVERLAY")
    data.arenaLabel = frame:CreateFontString(nil, "OVERLAY")
    data.nameHidden = CreateFrame("Frame", nil, data.visual)
    data.nameHidden:Hide()
end

local function Release(data)
    if data.labelActive then
        data.labelActive = nil
        if data.name:GetParent() == data.nameHidden then data.name:SetParent(data.nameParent or data.visual) end
    end
    if data.labelFrame then data.labelFrame:Hide() end
end

--- Places the label exactly where the client anchors the (now hidden) name.
local function CopyAnchors(label, name)
    label:ClearAllPoints()
    for index = 1, name:GetNumPoints() do label:SetPoint(name:GetPoint(index)) end
end

function me.UpdateLabel(plate, data)
    local cfg = me.Profile and me.Profile.labels
    local name = data.name and data.name:GetText()
    if not cfg or not name or not plate:IsShown() then return Release(data) end

    local text, active = name
    if cfg.className then
        local class = arenaClass[name] or (me.GetPlayerClass and me.GetPlayerClass(name))
        local localized = class and LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[class]
        if localized then text, active = localized, true end
    end
    local index = cfg.arena and inArena and arenaIndex[name]
    local standalone
    if index then
        active = true
        if cfg.arenaNumberOnly then text = nil end
        if cfg.arenaMode == "STACK" then
            text = text and (text .. " " .. index) or tostring(index)
        else
            standalone = index
        end
    end
    if not active then return Release(data) end

    Ensure(data)
    data.labelActive = true
    local parent = data.name:GetParent()
    if parent ~= data.nameHidden and parent ~= data.totemHidden then
        data.nameParent = parent
        data.name:SetParent(data.nameHidden)
    end
    data.labelFrame:SetFrameLevel(data.visual:GetFrameLevel() + 3)
    data.labelFrame:Show()
    local font, size, flags = data.name:GetFont()
    local r, g, b = data.name:GetTextColor()
    local label = data.label
    if text then
        if font then label:SetFont(font, size, flags) end
        CopyAnchors(label, data.name)
        label:SetTextColor(r, g, b)
        label:SetText(text)
        label:Show()
    else label:Hide() end
    local number = data.arenaLabel
    if standalone then
        number:SetFont(font or STANDARD_TEXT_FONT, cfg.arenaSize, "OUTLINE")
        number:SetTextColor(r, g, b)
        number:ClearAllPoints()
        number:SetPoint("CENTER", data.health or data.visual, "CENTER", cfg.arenaX, cfg.arenaY)
        number:SetFormattedText("%d", standalone)
        number:Show()
    else number:Hide() end
end

function me.UpdateLabels()
    if not me.Profile then return end
    RefreshArena()
    for plate, data in pairs(me.PlateData) do me.UpdateLabel(plate, data) end
end
