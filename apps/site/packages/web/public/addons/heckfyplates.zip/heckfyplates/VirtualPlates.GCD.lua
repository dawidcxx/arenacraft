-- Enemy GCD on nameplates. Ported from the "GCD Tracker" WeakAura by Friskes.
local _, me = ...
local frame = CreateFrame("Frame")
local active = {} -- [player name] = { start, duration, icon }, entries are reused
local units = { "target", "focus", "arena1", "arena2", "arena3", "arena4", "arena5" }
local pets = { "pet", "arenapet1", "arenapet2", "arenapet3", "partypet1", "partypet2" }
local buffNames = {} -- spellID -> localized name, filled lazily
local anyShown -- skip the plate loop entirely while nobody is on GCD

-- Spells that do not trigger the global cooldown.
local blackList = {
    -- NO GCD SPELL
    -- items
    [34722] = true, -- Плотные бинты из ледяной ткани
    [42292] = true, -- PvP-аксессуар
    [71607] = true, -- Выплеск света
    [54757] = true, -- Нарукавная зажигательная ракетница
    [54758] = true, -- Гиперскоростное ускорение
    -- sirus-wotlk-races
    [375020] = true, -- Дар скитальца
    [375016] = true, -- Металлический панцирь
    [375019] = true, -- Сверхтехнологичные ботинки
    [374997] = true, -- Преобразователь
    [374994] = true, -- Бычья поступь
    [374996] = true, -- Гнев Лоа
    [375038] = true, -- Зыбучие пески
    [375002] = true, -- Зов стаи
    [375015] = true, -- Неукротимость
    [374999] = true, -- Особенность рептилии
    [375018] = true, -- Объятия Элуны
    [374988] = true, -- Безудержная ярость
    [375035] = true, -- Поиск баланса
    [375024] = true, -- Надменный взор
    [374992] = true, -- Могильный зов
    [375001] = true, -- Пламя феникса
    [375040] = true, -- Полет дракона
    -- classic-wotlk-races
    [59752] = true, -- Каждый за себя
    [59542] = true, -- Дар наару
    [58984] = true, -- Слиться с тенью
    [7744] = true, -- Воля Отрекшихся
    [20549] = true, -- Громовая поступь
    [26297] = true, -- Берсерк
    [20594] = true, -- Каменная форма
    [20589] = true, -- Мастер побега
    [20572] = true, -- Кровавое неистовство
    [50613] = true, -- Волшебный поток
    -- hunter
    [781] = true, -- Отрыв
    [19263] = true, -- Сдерживание
    [5384] = true, -- Притвориться мертвым
    [48996] = true, -- Удар ящера
    [34026] = true, -- Команда "Взять!"
    [53271] = true, -- Приказ хозяина
    [3045] = true, -- Быстрая стрельба
    [34490] = true, -- Глушащий выстрел
    [34074] = true, -- Дух гадюки
    [5118] = true, -- Дух гепарда
    [49071] = true, -- Дух дикой природы
    [61847] = true, -- Дух дракондора
    [13161] = true, -- Дух зверя
    [13163] = true, -- Дух обезьяны
    [13159] = true, -- Дух стаи
    [27044] = true, -- Дух ястреба
    -- rogue
    [1766] = true, -- Пинок
    [26669] = true, -- Ускользание
    [11305] = true, -- Спринт
    [51713] = true, -- Танец теней
    [26889] = true, -- Исчезновение
    [1784] = true, -- Незаметность
    [14183] = true, -- Умысел
    [36554] = true, -- Шаг сквозь тень
    -- priest
    [14751] = true, -- Внутреннее сосредоточение
    [15487] = true, -- Безмолвие
    [10060] = true, -- Придание сил
    -- mage
    [12472] = true, -- Стылая кровь
    [11958] = true, -- Холодная хватка
    [2139] = true, -- Антимагия
    -- shaman
    [16166] = true, -- Покорение стихий
    [57994] = true, -- Пронизывающий ветер
    [55198] = true, -- Сила прилива
    [16188] = true, -- Природная стремительность
    -- paladin
    [31884] = true, -- Гнев карателя
    [62124] = true, -- Длань возмездия
    [31842] = true, -- Божественное просветление
    [31821] = true, -- Мастер аур
    -- warlock
    [18708] = true, -- Господство Скверны
    [36892] = true, -- Камень здоровья из Скверны
    -- deathknight
    [48707] = true, -- Антимагический панцирь
    [45529] = true, -- Кровоотвод
    [47528] = true, -- Заморозка разума
    [47568] = true, -- Усиление рунического оружия
    [48266] = true, -- Власть крови
    [48265] = true, -- Власть нечестивости
    [48263] = true, -- Власть льда
    [48792] = true, -- Незыблемость льда
    [49576] = true, -- Хватка смерти
    [56222] = true, -- Темная власть
    -- druid
    [33357] = true, -- Порыв
    [61336] = true, -- Инстинкты выживания
    [49376] = true, -- Звериная атака - кошка
    [5215] = true, -- Крадущийся зверь
    [50213] = true, -- Тигриное неистовство
    [16979] = true, -- Звериная атака - медведь
    [22812] = true, -- Дубовая кожа
    [5229] = true, -- Исступление
    [48480] = true, -- Трепка
    [6795] = true, -- Рык
    [17116] = true, -- Природная стремительность
    -- warrior
    [47450] = true, -- Удар героя
    [47520] = true, -- Рассекающий удар
    [2687] = true, -- Кровавая ярость
    [12328] = true, -- Размашистые удары
    [6552] = true, -- Зуботычина
    [11578] = true, -- Рывок
    [20252] = true, -- Перехват
    [355] = true, -- Провокация
    [2565] = true, -- Блок щитом
    [871] = true, -- Глухая оборона
    [23920] = true, -- Отражение заклинания
    [72] = true, -- Удар щитом
    [3411] = true, -- Вмешательство
}

-- Haste buffs: "percent" adds haste percent, "rating" is converted (32.79 rating = 1% at 80).
local hasteBuffs = {
    [64371] = { "percent", 20 },  -- Изничтожение
    [26297] = { "percent", 20 },  -- Берсерк
    [65264] = { "percent", 30 },  -- Потоки лавы
    [54153] = { "percent", 15 },  -- Безупречное правосудие
    [10060] = { "percent", 20 },  -- Придание сил
    [59891] = { "percent", 25 },  -- Лишнее время
    [32182] = { "percent", 30 },  -- Героизм
    [2825]  = { "percent", 30 },  -- Жажда крови
    [12472] = { "percent", 20 },  -- Стылая кровь
    [2895]  = { "percent", 5 },   -- Тотем гнева воздуха
    [64701] = { "percent", 15 },  -- Покорение стихий
    [54758] = { "rating", 340 },  -- Гиперскоростное ускорение
}
local shortGCD = { [7384] = true, [2457] = true, [2458] = true, [71] = true, [57823] = true } -- Overpower, stances, Revenge

local function BuffName(id)
    local name = buffNames[id]
    if name == nil then name = GetSpellInfo(id) or false; buffNames[id] = name end
    return name
end

local function HasBuff(unit, id)
    local name = BuffName(id)
    return name and UnitBuff(unit, name) and true or false
end

local function IsTotemSpell(name)
    return name and (name:find("отем", 1, true) or name:lower():find("totem", 1, true)) and true or false
end

local function BaseGCD(unit, spellID, spellName)
    if spellID == 47847 then return 0.5, true end -- Shadowfury: no haste applied
    if shortGCD[spellID] then return 1.0 end
    local _, class = UnitClass(unit)
    local caster = me.Profile.gcd.casterGCD
    if class == "ROGUE" then return 1.0
    elseif class == "PRIEST" or class == "MAGE" or class == "WARLOCK" then return caster
    elseif class == "SHAMAN" then return IsTotemSpell(spellName) and 1.0 or caster
    elseif class == "DEATHKNIGHT" then return HasBuff(unit, 48265) and 1.0 or 1.5 -- Unholy Presence
    elseif class == "DRUID" then return HasBuff(unit, 768) and 1.0 or 1.4 -- Cat Form
    end
    return 1.5
end

local function HastedGCD(unit, base)
    local haste = 0
    for id, buff in pairs(hasteBuffs) do
        if HasBuff(unit, id) then
            haste = haste + (buff[1] == "rating" and buff[2] / 32.79 or buff[2])
        end
    end
    if haste > 0 then base = base / (1 + haste / 100) end
    return math.max(1.0, base)
end

local function EnemyUnit(guid)
    for _, unit in ipairs(units) do
        if UnitIsPlayer(unit) and UnitGUID(unit) == guid then
            for _, pet in ipairs(pets) do
                if UnitIsUnit(unit, pet) then return end
            end
            if UnitCanAttack("player", unit) then return unit end
            return
        end
    end
end

local function Allowed()
    if not me.Profile.gcd.arenaOnly then return true end
    local _, instanceType = IsInInstance()
    return instanceType == "arena" and (GetNumPartyMembers() or 0) <= 1
end

local function OnEvent(_, event, _, subEvent, sourceGUID, _, _, _, _, _, spellID, spellName)
    if event == "PLAYER_ENTERING_WORLD" then
        for _, entry in pairs(active) do entry.start = nil end
        return
    end
    if subEvent ~= "SPELL_CAST_SUCCESS" or not me.Profile or not me.Profile.gcd.enabled then return end
    if blackList[spellID] or not Allowed() then return end
    local unit = EnemyUnit(sourceGUID)
    if not unit then return end
    local name = UnitName(unit)
    if not name then return end
    local duration, fixed = BaseGCD(unit, spellID, spellName)
    if not fixed then duration = HastedGCD(unit, duration) end
    local entry = active[name] or {}
    local _, _, icon = GetSpellInfo(spellID)
    entry.start, entry.duration, entry.icon = GetTime(), duration, icon
    active[name] = entry
end

local function Create(data)
    local f = CreateFrame("Frame", nil, data.visual)
    f:EnableMouse(false)
    f.icon = f:CreateTexture(nil, "ARTWORK")
    f.icon:SetAllPoints(f)
    f.icon:SetTexCoord(0.075, 0.925, 0.075, 0.925)
    f.shade = f:CreateTexture(nil, "OVERLAY")
    f.shade:SetTexture(0, 0, 0)
    f.shade:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 0, 0)
    f.shade:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 0)
    f.text = f:CreateFontString(nil, "OVERLAY")
    f.text:SetPoint("CENTER", f, "CENTER", 0, 0)
    data.gcd = f
    return f
end

function me.UpdateGCD()
    if not me.Profile then return end
    local cfg, now = me.Profile.gcd, GetTime()
    local any
    for name, entry in pairs(active) do
        if entry.start and now >= entry.start + entry.duration then entry.start = nil end
        if entry.start then any = true end
    end
    if not any and not anyShown then return end
    anyShown = any
    for plate, data in pairs(me.PlateData) do
        local f = data.gcd
        local name = data.name and data.name:GetText()
        local entry = cfg.enabled and plate:IsShown() and name and active[name]
        if entry and entry.start then
            f = f or Create(data)
            f:SetWidth(cfg.size)
            f:SetHeight(cfg.size)
            f:ClearAllPoints()
            f:SetPoint("TOP", data.visual, "TOP", cfg.x, cfg.y)
            f:SetFrameLevel(data.visual:GetFrameLevel() + 5)
            f.icon:SetTexture(entry.icon)
            local elapsed = math.min(1, (now - entry.start) / entry.duration)
            -- As in the aura: the shade grows from the bottom as the GCD passes.
            f.shade:SetHeight(math.max(0.001, cfg.size * elapsed))
            f.shade:SetAlpha(cfg.shade)
            if cfg.timer then
                f.text:SetFont(STANDARD_TEXT_FONT, cfg.timerSize, "OUTLINE")
                f.text:SetFormattedText("%.1f", entry.duration * (1 - elapsed))
                f.text:Show()
            else f.text:Hide() end
            f:Show()
        elseif f then f:Hide() end
    end
end

function me.InitializeGCD()
    frame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
    frame:RegisterEvent("PLAYER_ENTERING_WORLD")
    frame:SetScript("OnEvent", OnEvent)
    local elapsed = 0
    frame:SetScript("OnUpdate", function(_, delta)
        elapsed = elapsed + delta
        if elapsed >= 0.03 then elapsed = 0; me.UpdateGCD() end
    end)
end
