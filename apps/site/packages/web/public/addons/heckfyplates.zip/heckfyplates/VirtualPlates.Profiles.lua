local ADDON, me = ...

me.Defaults = {
    maxDistance = 0, -- yards from the camera, 0 = no limit
    virtual = {
        Version = me.Version, MinScale = 0, MaxScale = 3,
        MaxScaleEnabled = false, ScaleFactor = 10, VerticalOffset = 18,
    },
    cast = {
        enabled = true, width = 150, height = 11, x = 0, y = -5,
        texture = "Native", icon = true, spell = true, timer = true,
        timerFormat = "LEFT",
    },
    filters = {
        players = true, npcs = true, pets = true, minions = true,
        totems = true, overrides = {},
    },
    totem = { icon = false, iconOnly = false, size = 28, x = 0, y = 0,
        plateAlpha = 1, iconAlpha = 1 },
    names = { classColor = true, healthClassColor = false, keepFriendlyDefault = false },
    labels = { className = false, arena = false, arenaNumberOnly = false, arenaMode = "STACK",
        arenaSize = 14, arenaX = -70, arenaY = 0 },
    totemTicks = { mode = "TEXT_VERTICAL", opacity = 0.6, size = 11, x = 0, y = 0,
        intervals = { tremor = 3, cleansing = 3, earthbind = 3, searing = 2,
            magma = 2, healing_stream = 2, mana_spring = 2, mana_tide = 3 } },
    healthText = { enabled = true, remember = true, format = "PERCENT", size = 10, x = 0, y = 0 },
    combatText = { enabled = true, icon = "SWORDS", size = 18, x = 0, y = 28,
        showOut = false },
    gcd = { enabled = true, arenaOnly = true, size = 28, x = 90, y = 5,
        shade = 0.75, timer = false, timerSize = 13, casterGCD = 1.2 },
    fear = { enabled = true, size = 12, x = 0, y = -32,
        threshold = 10, fallbackHP = 20000 },
}

function me.Copy(source)
    local copy = {}
    for key, value in pairs(source) do
        copy[key] = type(value) == "table" and me.Copy(value) or value
    end
    return copy
end

local function Fill(target, defaults)
    if type(target) ~= "table" then target = {} end
    for key, value in pairs(defaults) do
        if type(value) == "table" then target[key] = Fill(target[key], value)
        elseif type(target[key]) ~= type(value) then target[key] = value end
    end
    return target
end

local function Clamp(value, low, high)
    if value ~= value then return low end
    return math.max(low, math.min(high, value))
end

function me.Normalize(profile)
    profile = Fill(profile, me.Defaults)
    -- Settings of removed click modes (AwesomeWotLK, /targetexact, expanded zone).
    profile.nativeClickLayout, profile.expandedClickArea = nil, nil
    profile.awesomeWotlk, profile.clickByName, profile.nameplateDistance = nil, nil, nil
    profile.maxDistance = math.floor(Clamp(profile.maxDistance, 0, 100) + 0.5)
    local v, c = profile.virtual, profile.cast
    v.MinScale = Clamp(v.MinScale, 0, 1)
    v.MaxScale = Clamp(v.MaxScale, math.max(0.1, v.MinScale), 10)
    v.ScaleFactor = Clamp(v.ScaleFactor, 5, 40)
    v.VerticalOffset = Clamp(v.VerticalOffset, -100, 100)
    c.width = Clamp(c.width, 40, 400)
    c.height = Clamp(c.height, 4, 50)
    c.x, c.y = Clamp(c.x, -200, 200), Clamp(c.y, -200, 200)
    local t = profile.totem
    t.size = Clamp(t.size, 8, 80)
    t.x, t.y = Clamp(t.x, -100, 100), Clamp(t.y, -100, 100)
    t.plateAlpha, t.iconAlpha = Clamp(t.plateAlpha, 0, 1), Clamp(t.iconAlpha, 0, 1)
    if t.iconOnly then t.icon = true end
    local ticks = profile.totemTicks
    local modes = { OFF = true, TEXT = true, VERTICAL = true, RADIAL = true,
        TEXT_VERTICAL = true, TEXT_RADIAL = true }
    if not modes[ticks.mode] then ticks.mode = "OFF" end
    ticks.opacity = Clamp(ticks.opacity, 0, 1)
    ticks.size = Clamp(ticks.size, 7, 24)
    ticks.x, ticks.y = Clamp(ticks.x, -40, 40), Clamp(ticks.y, -40, 40)
    for key, value in pairs(me.Defaults.totemTicks.intervals) do
        ticks.intervals[key] = Clamp(ticks.intervals[key], 0.5, 15)
    end
    for _, key in ipairs({ "healthText", "combatText", "fear" }) do
        local text = profile[key]
        text.size = Clamp(text.size, key == "combatText" and 8 or 7, key == "combatText" and 48 or 24)
        text.x, text.y = Clamp(text.x, -200, 200), Clamp(text.y, -200, 200)
    end
    profile.combatText.size = Clamp(profile.combatText.size, 8, 48)
    local formats = { CURRENT = true, CURRENT_MAX = true, PERCENT = true,
        CURRENT_PERCENT = true, CURRENT_MAX_PERCENT = true, MISSING = true }
    if not formats[profile.healthText.format] then profile.healthText.format = "PERCENT" end
    local icons = { SWORDS = true, ROLE = true, DUAL = true }
    if not icons[profile.combatText.icon] then profile.combatText.icon = "SWORDS" end
    local lb = profile.labels
    if lb.arenaMode ~= "STACK" and lb.arenaMode ~= "STANDALONE" then lb.arenaMode = "STACK" end
    lb.arenaSize = Clamp(lb.arenaSize, 7, 32)
    lb.arenaX, lb.arenaY = Clamp(lb.arenaX, -200, 200), Clamp(lb.arenaY, -200, 200)
    local g = profile.gcd
    g.size, g.shade = Clamp(g.size, 10, 64), Clamp(g.shade, 0, 1)
    g.x, g.y = Clamp(g.x, -200, 200), Clamp(g.y, -200, 200)
    g.timerSize, g.casterGCD = Clamp(g.timerSize, 7, 24), Clamp(g.casterGCD, 1, 1.5)
    profile.fear.threshold = Clamp(profile.fear.threshold, 1, 30)
    profile.fear.fallbackHP = Clamp(profile.fear.fallbackHP, 1000, 100000)
    if c.timerFormat ~= "LEFT" and c.timerFormat ~= "TOTAL" and c.timerFormat ~= "BOTH" then
        c.timerFormat = "LEFT"
    end
    if c.texture ~= "Native" and c.texture ~= "Blizzard" and c.texture ~= "LiteStep"
        and c.texture ~= "Flat" and c.texture ~= "Skills" then c.texture = "Native" end
    for key, value in pairs(profile.filters.overrides) do
        if type(value) ~= "boolean" then profile.filters.overrides[key] = nil end
    end
    profile.filters.custom = nil
    return profile
end

function me.SelectProfile(name)
    local db = me.DB
    db.profiles[name] = me.Normalize(db.profiles[name] or me.Copy(me.Defaults))
    db.characters[me.Character] = name
    me.Profile = db.profiles[name]
    me.OptionsCharacter = me.Profile.virtual
    _VirtualPlatesOptionsCharacter = me.OptionsCharacter
    if me.RefreshAll then me.RefreshAll() end
    if me.RefreshConfig then me.RefreshConfig() end
end

function me.InitializeProfiles()
    local db = type(VirtualPlatesDB) == "table" and VirtualPlatesDB or {}
    db.profiles = type(db.profiles) == "table" and db.profiles or {}
    db.characters = type(db.characters) == "table" and db.characters or {}
    db.migrated = type(db.migrated) == "table" and db.migrated or {}
    me.DB, VirtualPlatesDB = db, db
    me.Character = UnitName("player") .. " - " .. GetRealmName()
    if not db.migrated[me.Character] and not db.characters[me.Character] then
        local profile = me.Copy(me.Defaults)
        local old = _VirtualPlatesOptionsCharacter
        if type(old) == "table" then
            for key in pairs(profile.virtual) do
                if type(old[key]) == type(profile.virtual[key]) then profile.virtual[key] = old[key] end
            end
            if type(old.ScaleFactor1) == "number" and not old.ScaleFactor then
                profile.virtual.ScaleFactor = old.ScaleFactor1
            end
        end
        local castDB = PlateCastBar_SavedVariables
        local cast = type(castDB) == "table" and castDB or nil
        if cast and type(cast.profiles) == "table" then
            local name = type(cast.characters) == "table" and cast.characters[me.Character] or me.Character
            cast = cast.profiles[name]
        end
        if type(cast) == "table" then
            for key in pairs(profile.cast) do
                if type(cast[key]) == type(profile.cast[key]) then profile.cast[key] = cast[key] end
            end
            if type(cast.CastBar) == "table" then
                local bar = cast.CastBar
                profile.cast.width = bar.Width or 150
                profile.cast.height = bar.Height or 11
                profile.cast.x, profile.cast.y = bar.PointX or 6, bar.PointY or -5
                profile.cast.texture = "LiteStep"
            end
            if type(cast.Enable) == "table" then
                for key, oldKey in pairs({ icon = "Icon", spell = "Spell", timer = "Timer" }) do
                    if type(cast.Enable[oldKey]) == "boolean" then profile.cast[key] = cast.Enable[oldKey] end
                end
            end
            if type(cast.Timer) == "table" then profile.cast.timerFormat = cast.Timer.Format or "LEFT" end
        end
        local name = me.Character
        while db.profiles[name] do name = name .. " (new)" end
        db.profiles[name] = me.Normalize(profile)
        db.characters[me.Character] = name
    end
    db.migrated[me.Character], db.version = true, 1
    me.SelectProfile(db.characters[me.Character] or me.Character)
end

function me.RefreshAll()
    if not me.Profile then return end
    for plate, data in pairs(me.PlateData) do
        me.UpdateClickZone(plate)
        if me.StyleCastBar and data.bar then me.StyleCastBar(data.bar, data) end
        if me.RefreshNativeVisibility then me.RefreshNativeVisibility(data) end
    end
    if me.UpdateFilters then me.UpdateFilters() end
    if me.UpdateIndicators then me.UpdateIndicators() end
    if me.UpdateTotemTicks then me.UpdateTotemTicks() end
end

function me.InitializeModules()
    me.InitializeClickZone()
    me.InitializeFilters()
    me.InitializeTotemTicks()
    me.InitializeCastBars()
    me.InitializeIndicators()
    me.InitializeFear()
    me.InitializeGCD()
    me.BuildConfig()
end
