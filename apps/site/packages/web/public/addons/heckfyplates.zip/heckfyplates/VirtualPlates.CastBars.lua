local ADDON, me = ...
local texturePaths = {
    Blizzard = "Interface\\TargetingFrame\\UI-StatusBar",
    Native = "Interface\\TargetingFrame\\UI-StatusBar",
    LiteStep = "Interface\\AddOns\\" .. ADDON .. "\\Textures\\LiteStep.tga",
    Flat = "Interface\\Buttons\\WHITE8X8",
    Skills = "Interface\\PaperDollInfoFrame\\UI-Character-Skills-Bar",
}
local castFrame = CreateFrame("Frame")

local function Toggle(region, enabled)
    if enabled then region:Show() else region:Hide() end
end

local function CaptureNative(data)
    local native = data.nativeCast
    if not native or not native.GetStatusBarTexture then return end
    local fill = native:GetStatusBarTexture()
    data.nativeTexture = fill and fill:GetTexture()
    native:HookScript("OnShow", function()
        data.lastNativeValue, data.nativeChannel = nil, nil
    end)
end

function me.RefreshNativeVisibility(data)
    -- Alpha leaves IsShown/value updates intact, so patched-client cast data remain readable.
    if data.nativeCast then data.nativeCast:SetAlpha(0) end
    if data.nativeBorder then data.nativeBorder:SetAlpha(0) end
    if data.nativeShield then data.nativeShield:SetAlpha(0) end
    if data.nativeIcon then data.nativeIcon:SetAlpha(0) end
    if data.bar and not me.Profile.cast.enabled then data.bar:Hide() end
end

function me.StyleCastBar(bar, data)
    local c = me.Profile.cast
    bar:SetWidth(c.width)
    bar:SetHeight(c.height)
    bar:SetStatusBarTexture(c.texture == "Native" and data and data.nativeTexture or texturePaths[c.texture])
    local native = c.texture == "Native"
    -- Blizzard's small frame surrounds a 150x10 fill inside a 197x49 texture.
    -- Its transparent padding requires a 0.5-unit vertical offset at native size.
    bar.border:SetTexture("Interface\\CastingBar\\UI-CastingBar-Border-Small")
    bar.border:SetTexCoord(0, 1, 0, 1)
    bar.border:SetWidth(c.width * 197 / 150)
    bar.border:SetHeight(c.height * 49 / 10)
    bar.border:ClearAllPoints()
    bar.border:SetPoint("CENTER", bar, "CENTER", 0, c.height * 0.05)
    Toggle(bar.border, native)
    bar.shield:SetTexture("Interface\\CastingBar\\UI-CastingBar-Small-Shield")
    bar.shield:SetTexCoord(0, 1, 0, 1)
    bar.shield:ClearAllPoints()
    bar.shield:SetAllPoints(bar.border)
    Toggle(bar.shield, native and bar.locked)
    bar:SetBackdropBorderColor(0, 0, 0, native and 0 or 1)
    bar.icon:SetWidth(c.height + 2)
    bar.icon:SetHeight(c.height + 2)
    local fontSize = math.max(9, math.min(16, c.height))
    bar.spell:SetFont(STANDARD_TEXT_FONT, fontSize, "OUTLINE")
    bar.timer:SetFont(STANDARD_TEXT_FONT, fontSize, "OUTLINE")
    bar.spell:ClearAllPoints()
    bar.spell:SetPoint("LEFT", bar, "LEFT", 3, 0)
    bar.spell:SetPoint("RIGHT", bar, "RIGHT", c.timer and -(c.timerFormat == "BOTH" and 85 or 40) or -3, 0)
    bar.spell:SetHeight(c.height + 4)
    bar.timer:SetWidth(c.timerFormat == "BOTH" and 80 or 35)
    bar.timer:SetHeight(c.height + 4)
    bar.spark:SetWidth(12)
    bar.spark:SetHeight(c.height * 2)
    Toggle(bar.icon, c.icon)
    Toggle(bar.spell, c.spell)
    Toggle(bar.timer, c.timer)
    Toggle(bar.spark, native)
    if data then
        bar:ClearAllPoints()
        bar:SetPoint("TOP", data.health or data.anchor, "BOTTOM", c.x, c.y)
    end
end

function me.CreateCastBar(parent, data)
    local bar = CreateFrame("StatusBar", nil, parent)
    bar:EnableMouse(false)
    bar:SetFrameLevel(parent:GetFrameLevel() + 1)
    bar:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    bar:SetBackdropColor(0.08, 0.08, 0.08, 0.85)
    bar.border = bar:CreateTexture(nil, "OVERLAY")
    bar.shield = bar:CreateTexture(nil, "OVERLAY")
    bar.spark = bar:CreateTexture(nil, "OVERLAY")
    bar.spark:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark")
    bar.spark:SetBlendMode("ADD")
    bar.icon = bar:CreateTexture(nil, "OVERLAY")
    bar.icon:SetPoint("RIGHT", bar, "LEFT", -3, 0)
    bar.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    bar.spell = bar:CreateFontString(nil, "OVERLAY")
    bar.spell:SetJustifyH("LEFT")
    bar.timer = bar:CreateFontString(nil, "OVERLAY")
    bar.timer:SetPoint("RIGHT", bar, "RIGHT", -3, 0)
    bar.timer:SetJustifyH("RIGHT")
    me.StyleCastBar(bar, data)
    bar:Hide()
    return bar
end

--- Reads a unit's cast; fills `out` when given instead of creating a table.
function me.ReadUnitCast(unit, out)
    local name, _, _, icon, startTime, endTime, _, _, locked = UnitCastingInfo(unit)
    local channel = false
    if not name then
        name, _, _, icon, startTime, endTime, _, locked = UnitChannelInfo(unit)
        channel = true
    end
    if name and startTime and endTime and endTime > startTime then
        out = out or {}
        out.name, out.icon, out.start, out.finish = name, icon, startTime / 1000, endTime / 1000
        out.channel, out.locked = channel, locked
        return out
    end
end

local function Paint(bar, value, duration, remaining, name, icon, locked)
    local c = me.Profile.cast
    value = math.max(0, math.min(duration, value))
    remaining = math.max(0, math.min(duration, remaining))
    bar:SetMinMaxValues(0, duration)
    bar:SetValue(value)
    if locked then bar:SetStatusBarColor(0.65, 0.65, 0.65)
    else bar:SetStatusBarColor(1, 0.7, 0) end
    bar.locked = locked
    Toggle(bar.shield, c.texture == "Native" and locked)
    Toggle(bar.border, c.texture == "Native" and not locked)
    bar.spell:SetText(name or "")
    bar.icon:SetTexture(icon)
    Toggle(bar.icon, c.icon and icon)
    if c.timerFormat == "TOTAL" then bar.timer:SetFormattedText("%.1f", duration)
    elseif c.timerFormat == "BOTH" then bar.timer:SetFormattedText("%.1f / %.1f", remaining, duration)
    else bar.timer:SetFormattedText("%.1f", remaining) end
    bar.spark:ClearAllPoints()
    bar.spark:SetPoint("CENTER", bar, "LEFT", duration > 0 and c.width * value / duration or 0, 0)
    bar:Show()
end

function me.PaintUnitCast(bar, cast, now)
    local duration = cast.finish - cast.start
    local remaining = math.max(0, math.min(duration, cast.finish - now))
    if now >= cast.finish then bar:Hide(); return end
    Paint(bar, cast.channel and remaining or duration - remaining, duration,
        remaining, cast.name, cast.icon, cast.locked)
end

local function PaintNative(data)
    local native = data.nativeCast
    if not native or not native.GetMinMaxValues or not native:IsShown() then
        data.lastNativeValue, data.nativeChannel = nil, nil
        return false
    end
    local minimum, maximum = native:GetMinMaxValues()
    local value = native:GetValue() - minimum
    local duration = maximum - minimum
    if duration <= 0 or value < 0 or value > duration then return false end
    if data.lastNativeValue then
        if value < data.lastNativeValue - 0.001 then data.nativeChannel = true
        elseif value > data.lastNativeValue + 0.001 then data.nativeChannel = false end
    end
    data.lastNativeValue = value
    local remaining = data.nativeChannel and value or duration - value
    local icon = data.nativeIcon and data.nativeIcon:GetTexture()
    local shieldTexture = data.nativeShield and data.nativeShield:GetTexture()
    local locked = type(shieldTexture) == "string" and shieldTexture:lower():find("shield", 1, true)
        and data.nativeShield:IsShown()
    Paint(data.bar, value, duration, remaining, nil, icon, locked)
    return true
end

-- Reused every update instead of allocating new tables 20 times a second.
local casts, seen, counts, castPool = {}, {}, {}, {}
local preview = { icon = "Interface\\Icons\\Spell_Frost_FrostBolt02" }

function me.UpdateCastBars()
    if not me.Profile then return end
    local c = me.Profile.cast
    wipe(casts); wipe(seen); wipe(counts)
    local now = GetTime()
    if c.enabled then
        for plate, data in pairs(me.PlateData) do
            if plate:IsShown() and data.name then
                local name = data.name:GetText()
                if name then counts[name] = (counts[name] or 0) + 1 end
            end
        end
        for _, unit in ipairs(me.Units) do
            if UnitExists(unit) then
                local guid, name = UnitGUID(unit), UnitName(unit)
                if guid and name and not seen[guid] then
                    seen[guid] = true
                    local cast = me.ReadUnitCast(unit, castPool[unit])
                    if cast then
                        castPool[unit] = cast
                        if casts[name] then casts[name] = false
                        elseif casts[name] == nil then casts[name] = cast end
                    end
                end
            end
        end
    end
    for plate, data in pairs(me.PlateData) do
        if not data.bar then
            CaptureNative(data)
            data.bar = me.CreateCastBar(data.visual, data)
        end
        me.RefreshNativeVisibility(data)
        if c.enabled and plate:IsShown() and not data.filtered
            and not (data.totemStyle and data.totemStyle.iconOnly) then
            local name = data.name and data.name:GetText()
            local cast = name and counts[name] == 1 and casts[name]
            -- Remembered for the fast fill update between unit scans.
            data.castSource = cast or nil
            if cast then me.PaintUnitCast(data.bar, cast, now)
            elseif not PaintNative(data) then data.bar:Hide() end
        else
            data.castSource = nil
            data.bar:Hide()
        end
    end
    if me.Preview and me.CastPanel:IsShown() then
        if c.enabled then
            preview.name = GetSpellInfo(116) or "Frostbolt"
            preview.start, preview.finish = now - now % 3, now - now % 3 + 3
            me.PaintUnitCast(me.Preview, preview, now)
        else me.Preview:Hide() end
    end
end

--- Repaints only visible bars from the last scan: fill, spark and timer.
local function PaintCastBars()
    local now = GetTime()
    for plate, data in pairs(me.PlateData) do
        local bar = data.bar
        if bar and bar:IsShown() then
            if data.castSource then me.PaintUnitCast(bar, data.castSource, now)
            elseif not PaintNative(data) then bar:Hide() end
        end
    end
end

function me.InitializeCastBars()
    -- Unit scan every 0.05 s; bar fill every 0.01 s (in practice every frame).
    local scanElapsed, paintElapsed = 0, 0
    castFrame:SetScript("OnUpdate", function(_, delta)
        scanElapsed, paintElapsed = scanElapsed + delta, paintElapsed + delta
        if scanElapsed >= 0.05 then
            scanElapsed, paintElapsed = 0, 0
            me.UpdateCastBars()
        elseif paintElapsed >= 0.01 then
            paintElapsed = 0
            if me.Profile and me.Profile.cast.enabled then PaintCastBars() end
        end
    end)
end
