local _, me = ...
local entries = {}
for _, entry in ipairs(me.FilterEntries) do
    if entry[2] == "totems" then entries[entry[1]] = entry end
end

local function Restore(data)
    data.totemStyle = nil
    if data.totemParents then
        for region, parent in pairs(data.totemParents) do region:SetParent(parent) end
        data.totemParents = nil
    end
    if data.bar then data.bar:SetAlpha(1) end
    if data.totemOriginalAlpha then
        for region, alpha in pairs(data.totemOriginalAlpha) do region:SetAlpha(alpha) end
        data.totemOriginalAlpha = nil
    end
    if data.totemIcon then data.totemIcon:Hide() end
    data.totemStyle = nil
end

function me.EnforceTotemAppearance(plate, data)
    local style = data.totemStyle
    if not style then return end
    if style.iconOnly then
        if not data.totemHidden then
            data.totemHidden = CreateFrame("Frame", nil, data.visual)
            data.totemHidden:EnableMouse(false)
        end
        data.totemHidden:Hide()
        data.totemParents = data.totemParents or {}
        for _, region in ipairs(plate) do
            if not data.totemParents[region] then data.totemParents[region] = region:GetParent() end
            if region:GetParent() ~= data.totemHidden then region:SetParent(data.totemHidden) end
        end
    elseif data.totemParents then
        for region, parent in pairs(data.totemParents) do region:SetParent(parent) end
        data.totemParents = nil
    end
    for _, region in ipairs(plate) do
        local alpha = style.iconOnly and 0 or style.plateAlpha
        if region:GetAlpha() ~= alpha then region:SetAlpha(alpha) end
    end
end

function me.StyleTotem(plate, data)
    local category, key = me.ResolveFilter(data.name:GetText())
    local entry = category == "totems" and entries[key]
    if not entry then
        Restore(data)
        if me.RefreshNativeVisibility then me.RefreshNativeVisibility(data) end
        me.UpdateClickZone(plate)
        return
    end
    do
        -- One style table per plate, refreshed in place (the totem profile holds only plain values).
        local style = data.totemStyleTable or {}
        for key, value in pairs(me.Profile.totem) do style[key] = value end
        data.totemStyleTable, data.totemStyle = style, style
        if not data.totemIcon then
            data.totemIcon = CreateFrame("Frame", nil, data.visual)
            data.totemIcon:EnableMouse(false)
            data.totemIcon.texture = data.totemIcon:CreateTexture(nil, "ARTWORK")
            data.totemIcon.texture:SetAllPoints(data.totemIcon)
            data.totemIcon.texture:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        end
        local icon = data.totemIcon
        icon:SetWidth(data.totemStyle.size)
        icon:SetHeight(data.totemStyle.size)
        icon:ClearAllPoints()
        icon:SetPoint("CENTER", data.health or data.visual, "CENTER", data.totemStyle.x, data.totemStyle.y)
    end
    local style = data.totemStyle
    if not style then return end
    data.totemOriginalAlpha = data.totemOriginalAlpha or {}
    if not data.totemAppearanceHooks then
        data.totemAppearanceHooks = true
        for _, region in ipairs(plate) do
            hooksecurefunc(region, "SetAlpha", function(self, alpha)
                local active = data.totemStyle
                if active and active.iconOnly and alpha ~= 0 then self:SetAlpha(0) end
            end)
            hooksecurefunc(region, "Show", function(self)
                if data.totemStyle and data.totemStyle.iconOnly then self:SetAlpha(0) end
            end)
        end
    end
    for _, region in ipairs(plate) do
        if data.totemOriginalAlpha[region] == nil then
            data.totemOriginalAlpha[region] = region:GetAlpha()
        end
        region:SetAlpha(style.iconOnly and 0 or style.plateAlpha)
    end
    local icon = data.totemIcon
    local _, _, texture = GetSpellInfo(entry[3])
    icon.texture:SetTexture(texture or "Interface\\Icons\\INV_Misc_QuestionMark")
    icon:SetAlpha(style.iconAlpha)
    if style.icon and not data.filtered then icon:Show() else icon:Hide() end
    if data.bar then data.bar:SetAlpha(style.iconOnly and 0 or style.plateAlpha) end
    if me.RefreshNativeVisibility then me.RefreshNativeVisibility(data) end
    me.EnforceTotemAppearance(plate, data)
    me.UpdateClickZone(plate)
end
