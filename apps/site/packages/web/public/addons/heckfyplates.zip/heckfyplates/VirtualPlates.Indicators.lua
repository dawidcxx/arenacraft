local _, me = ...
local frame = CreateFrame("Frame")
local combat, classNames = {}, {}
-- Reused tables: snapshots are rebuilt 10 times a second, records only live for one update.
local snapshotSeen, snapshotPool, counts = {}, {}, {}
local WHITE = { 1, 1, 1 }
me.UnitSnapshots = {}
me.HealthMemory = {}
me.HealthMemoryNames = {}

function me.EnforcePlateColors(data)
    if data.highlight then data.highlight:SetAlpha(0) end
    if data.coloredName and data.appliedNameColor then
        data.name:SetTextColor(unpack(data.appliedNameColor))
    end
    if data.coloredHealth and data.appliedHealthColor then
        data.health:SetStatusBarColor(unpack(data.appliedHealthColor))
    end
end

--- Called when a plate hides: the client reuses the frame for another unit,
-- so colours applied for the previous unit must not follow it.
function me.ResetPlateColors(data)
    if data.coloredName and data.originalNameColor then
        data.name:SetTextColor(unpack(data.originalNameColor))
    end
    if data.coloredHealth and data.originalHealthColor and data.health then
        data.health:SetStatusBarColor(unpack(data.originalHealthColor))
    end
    data.coloredName, data.appliedNameColor, data.originalNameColor = nil, nil, nil
    data.coloredHealth, data.appliedHealthColor, data.originalHealthColor = nil, nil, nil
end

--- Class token of a player name seen through unit IDs or the combat log, if known.
function me.GetPlayerClass(name)
    local record = classNames[name]
    return record and record.class
end

function me.FindUnitForGUID(guid)
    for _, unit in ipairs(me.Units) do
        if UnitExists(unit) and UnitGUID(unit) == guid then return unit end
    end
end

--- Updates a class record in place; creates it only for a new name.
local function SetClassName(name, class, time, guid, friendly)
    local record = classNames[name]
    if record then
        record.class, record.time, record.guid, record.friendly = class, time, guid, friendly
    else
        classNames[name] = { class = class, time = time, guid = guid, friendly = friendly }
    end
end

local function Snapshots()
    local byName, seen = me.UnitSnapshots, snapshotSeen
    wipe(byName); wipe(seen)
    local now = GetTime()
    for _, unit in ipairs(me.Units) do
        if UnitExists(unit) then
            local guid, name = UnitGUID(unit), UnitName(unit)
            if guid and name and not seen[guid] then
                seen[guid] = true
                local player = UnitIsPlayer(unit)
                local _, class = UnitClass(unit)
                local fighting = UnitAffectingCombat(unit) and true or false
                local state = combat[guid]
                if not state then
                    state = { fighting = fighting, entered = fighting and now or nil }
                    combat[guid] = state
                elseif state.fighting ~= fighting then
                    state.fighting = fighting
                    if fighting then state.entered = now; state.left = nil
                    else state.left = now; state.entered = nil end
                end
                state.observed = now
                local record = snapshotPool[unit]
                if not record then record = {}; snapshotPool[unit] = record end
                record.unit, record.guid, record.player, record.class = unit, guid, player, class
                record.friendly = UnitIsFriend("player", unit) and true or false
                record.hp, record.maxHP, record.combat = UnitHealth(unit), UnitHealthMax(unit), state
                if player and class then
                    SetClassName(name, class, now, guid, record.friendly)
                end
                if me.Profile.healthText.remember and record.maxHP > 0 then
                    local memory = me.HealthMemory[guid]
                    if memory then memory.hp, memory.maxHP, memory.name = record.hp, record.maxHP, name
                    else me.HealthMemory[guid] = { hp = record.hp, maxHP = record.maxHP, name = name } end
                    if player then
                        local previous = me.HealthMemoryNames[name]
                        if previous == nil then me.HealthMemoryNames[name] = guid
                        elseif previous ~= guid then me.HealthMemoryNames[name] = false end
                    end
                end
                if byName[name] then byName[name] = false
                elseif byName[name] == nil then byName[name] = record end
            end
        end
    end
    for guid, state in pairs(combat) do
        if now - state.observed > 30 then combat[guid] = nil end
    end
    for name, record in pairs(classNames) do
        if now - record.time > 300 then classNames[name] = nil end
    end
end

function me.FormatHealth(hp, maxHP, format, exact)
    if not maxHP or maxHP <= 0 then return "" end
    hp = math.max(0, math.min(maxHP, hp))
    local percent = math.floor(hp / maxHP * 100 + 0.5)
    if not exact or format == "PERCENT" then return percent .. "%" end
    hp, maxHP = math.floor(hp + 0.5), math.floor(maxHP + 0.5)
    if format == "CURRENT" then return tostring(hp)
    elseif format == "CURRENT_MAX" then return hp .. " / " .. maxHP
    elseif format == "CURRENT_PERCENT" then return hp .. " (" .. percent .. "%)"
    elseif format == "CURRENT_MAX_PERCENT" then return hp .. " / " .. maxHP .. " (" .. percent .. "%)"
    elseif format == "MISSING" then return "-" .. (maxHP - hp) end
    return percent .. "%"
end

local function CreateText(data)
    local overlay = CreateFrame("Frame", nil, data.visual)
    overlay:EnableMouse(false)
    overlay:SetFrameLevel(data.visual:GetFrameLevel() + 2)
    data.infoFrame = overlay
    data.hpText = overlay:CreateFontString(nil, "OVERLAY")
    data.combatIcon = overlay:CreateTexture(nil, "OVERLAY")
    data.fearText = overlay:CreateFontString(nil, "OVERLAY")
end

local function Style(text, settings, anchor, point, relativePoint, color)
    text:SetFont(STANDARD_TEXT_FONT, settings.size, "OUTLINE")
    text:ClearAllPoints()
    text:SetPoint(point, anchor, relativePoint, settings.x, settings.y)
    text:SetTextColor(unpack(color))
end

local function NameColor(data, name, meta, unique)
    if not data.colorHooks then
        data.colorHooks = true
        hooksecurefunc(data.name, "SetTextColor", function(self, r, g, b)
            local color = data.coloredName and data.appliedNameColor
            if color and (r ~= color[1] or g ~= color[2] or b ~= color[3]) then
                self:SetTextColor(unpack(color))
            end
        end)
        if data.health then
            hooksecurefunc(data.health, "SetStatusBarColor", function(self, r, g, b)
                local color = data.coloredHealth and data.appliedHealthColor
                if color and (r ~= color[1] or g ~= color[2] or b ~= color[3]) then
                    self:SetStatusBarColor(unpack(color))
                end
            end)
        end
    end
    local class = meta and meta.player and meta.class
    if not meta and unique and classNames[name] then class = classNames[name].class end
    local color = class and RAID_CLASS_COLORS[class]
    if me.Profile.names.keepFriendlyDefault then
        local friendly
        if meta then friendly = meta.friendly
        elseif unique and classNames[name] then friendly = classNames[name].friendly end
        -- An unknown reaction is not enough to identify a hostile player.
        if friendly ~= false then color = nil end
    end
    if data.health then
        if data.coloredHealth and data.coloredHealth ~= name then
            local r, g, b = data.health:GetStatusBarColor()
            local previous = data.appliedHealthColor
            if previous and r == previous[1] and g == previous[2] and b == previous[3] then
                data.coloredHealth = nil
                data.health:SetStatusBarColor(unpack(data.originalHealthColor))
            end
            data.originalHealthColor, data.coloredHealth = nil, nil
        end
        if me.Profile.names.healthClassColor and color and unique then
            if not data.originalHealthColor then
                data.originalHealthColor = { data.health:GetStatusBarColor() }
            end
            data.coloredHealth = name
            -- Updated in place: the previous value was already compared above.
            local applied = data.appliedHealthColor or {}
            applied[1], applied[2], applied[3] = color.r, color.g, color.b
            data.appliedHealthColor = applied
            data.health:SetStatusBarColor(color.r, color.g, color.b)
        elseif data.originalHealthColor then
            data.coloredHealth = nil
            data.health:SetStatusBarColor(unpack(data.originalHealthColor))
            data.originalHealthColor, data.coloredHealth = nil, nil
        end
    end
    if data.coloredName and data.coloredName ~= name then
        local r, g, b = data.name:GetTextColor()
        local previous = data.appliedNameColor
        if previous and r == previous[1] and g == previous[2] and b == previous[3] then
            data.coloredName = nil
            data.name:SetTextColor(unpack(data.originalNameColor))
        end
        data.originalNameColor, data.coloredName = nil, nil
    end
    if me.Profile.names.classColor and color and unique then
        if not data.originalNameColor then data.originalNameColor = { data.name:GetTextColor() } end
        data.coloredName = name
        local applied = data.appliedNameColor or {}
        applied[1], applied[2], applied[3] = color.r, color.g, color.b
        data.appliedNameColor = applied
        data.name:SetTextColor(color.r, color.g, color.b)
    elseif data.originalNameColor then
        data.coloredName = nil
        data.name:SetTextColor(unpack(data.originalNameColor))
        data.originalNameColor, data.coloredName = nil, nil
    end
end

function me.UpdateIndicators()
    if not me.Profile then return end
    Snapshots()
    wipe(counts)
    for plate, data in pairs(me.PlateData) do
        if plate:IsShown() and data.name then
            local name = data.name:GetText()
            counts[name] = (counts[name] or 0) + 1
        end
    end
    for plate, data in pairs(me.PlateData) do
        if data.name then
            if not data.infoFrame then CreateText(data) end
            local name = data.name:GetText()
            local meta = counts[name] == 1 and me.UnitSnapshots[name] or nil
            if data.hpMemoryName ~= name or not plate:IsShown() then
                data.hpMemoryGUID, data.hpMemoryName = nil, nil
            end
            if meta and me.Profile.healthText.remember and meta.maxHP > 0 then
                data.hpMemoryGUID, data.hpMemoryName = meta.guid, name
            end
            NameColor(data, name, meta, counts[name] == 1 and me.UnitSnapshots[name] ~= false)
            local visible = plate:IsShown() and not data.filtered
                and not (data.totemStyle and data.totemStyle.iconOnly)
            local category = me.ResolveFilter(name)
            data.infoFrame:SetAlpha(data.totemStyle and data.totemStyle.plateAlpha or 1)
            local health = me.Profile.healthText
            Style(data.hpText, health, data.health or data.visual, "CENTER", "CENTER", WHITE)
            data.hpText:SetWidth(math.max(20, (data.health or data.visual):GetWidth() - 4))
            data.hpText:SetHeight(health.size + 4)
            if visible and category ~= "totems" and health.enabled and data.health then
                local hp, maxHP, exact
                if meta then hp, maxHP, exact = meta.hp, meta.maxHP, true
                else
                    local minimum, maximum = data.health:GetMinMaxValues()
                    hp, maxHP = data.health:GetValue() - minimum, maximum - minimum
                    local remembered = health.remember and counts[name] == 1
                        and me.UnitSnapshots[name] ~= false
                        and me.HealthMemory[data.hpMemoryGUID or me.HealthMemoryNames[name]]
                    if remembered and maxHP > 0 then
                        hp = math.floor(hp / maxHP * remembered.maxHP + 0.5)
                        maxHP, exact = remembered.maxHP, true
                    end
                end
                local value = me.FormatHealth(hp, maxHP, health.format, exact)
                data.hpText:SetText(value)
                data.hpText:Show()
            else data.hpText:Hide() end
            local cfg = me.Profile.combatText
            local icon = data.combatIcon
            icon:ClearAllPoints()
            icon:SetPoint("BOTTOM", data.health or data.visual, "TOP", cfg.x, cfg.y)
            icon:SetWidth(cfg.size)
            icon:SetHeight(cfg.size)
            if cfg.icon == "ROLE" then
                icon:SetTexture("Interface\\LFGFrame\\UI-LFG-ICON-PORTRAITROLES")
                icon:SetTexCoord(20/64, 39/64, 22/64, 41/64)
            elseif cfg.icon == "DUAL" then
                icon:SetTexture("Interface\\Icons\\Ability_DualWield")
                icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
            else
                icon:SetTexture("Interface\\CharacterFrame\\UI-StateIcon")
                icon:SetTexCoord(0.5, 1, 0, 0.5)
            end
            if visible and cfg.enabled and meta and (meta.combat.fighting or cfg.showOut) then
                local fighting = meta.combat.fighting
                icon:SetVertexColor(fighting and 1 or 0.45, fighting and 1 or 0.45, fighting and 1 or 0.45)
                icon:SetAlpha(fighting and 1 or 0.5)
                icon:Show()
            else icon:Hide() end
            if me.DrawFear then me.DrawFear(data, meta,
                visible and counts[name] == 1 and me.UnitSnapshots[name] ~= false, GetTime()) end
        end
    end
    if me.UpdateLabels then me.UpdateLabels() end
end

function me.InitializeIndicators()
    frame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
    frame:RegisterEvent("PLAYER_ENTERING_WORLD")
    frame:SetScript("OnEvent", function(_, event, timestamp, kind, sourceGUID, sourceName, sourceFlags,
        destGUID, destName, destFlags)
        if event == "PLAYER_ENTERING_WORLD" then wipe(combat); wipe(classNames); return end
        if not GetPlayerInfoByGUID then return end
        local function Record(guid, name, flags)
            if guid and name and flags and bit.band(flags, COMBATLOG_OBJECT_TYPE_PLAYER or 0x400) ~= 0 then
                local _, class = GetPlayerInfoByGUID(guid)
                if class then
                    local friendly
                    if bit.band(flags, 0x10) ~= 0 then friendly = true
                    elseif bit.band(flags, 0x60) ~= 0 then friendly = false end
                    if friendly == nil and classNames[name] and classNames[name].guid == guid then
                        friendly = classNames[name].friendly
                    end
                    SetClassName(name, class, GetTime(), guid, friendly)
                end
            end
        end
        Record(sourceGUID, sourceName, sourceFlags)
        Record(destGUID, destName, destFlags)
    end)
    local elapsed = 0
    frame:SetScript("OnUpdate", function(_, delta)
        elapsed = elapsed + delta
        if elapsed >= 0.1 then elapsed = 0; me.UpdateIndicators() end
    end)
end
