-- Adapted from HeckfyFearThreshold by Heckfy; values are an estimated damage budget.
local _, me = ...
local frame = CreateFrame("Frame")
local fears = {}
local psychicScream = { [8122] = true, [8124] = true, [10888] = true, [10890] = true }
local damageEvents = { SWING_DAMAGE = true, RANGE_DAMAGE = true, SPELL_DAMAGE = true,
    SPELL_PERIODIC_DAMAGE = true, DAMAGE_SHIELD = true, DAMAGE_SPLIT = true,
    ENVIRONMENTAL_DAMAGE = true }

local function MaxHealth(guid)
    local unit = me.FindUnitForGUID(guid)
    if unit then
        local value = UnitHealthMax(unit)
        if value and value > 0 then return value, true end
    end
    return me.Profile.fear.fallbackHP, false
end

function me.FearOnEvent(_, event, timestamp, kind, sourceGUID, sourceName, sourceFlags,
    destGUID, destName, destFlags, arg9, arg10, arg11, arg12, arg13)
    if event == "PLAYER_ENTERING_WORLD" then wipe(fears); return end
    if not kind or not destGUID or not me.Profile then return end
    local isFear = psychicScream[arg9]
    if isFear and (kind == "SPELL_AURA_APPLIED" or kind == "SPELL_AURA_REFRESH") then
        local maxHP, known = MaxHealth(destGUID)
        fears[destGUID] = { name = destName, maxHP = maxHP, known = known,
            damage = 0, expires = GetTime() + 8.5 }
    elseif (isFear and (kind == "SPELL_AURA_REMOVED" or kind == "SPELL_AURA_BROKEN"
        or kind == "SPELL_AURA_BROKEN_SPELL")) or kind == "UNIT_DIED" or kind == "UNIT_DESTROYED" then
        fears[destGUID] = nil
    elseif damageEvents[kind] and fears[destGUID] then
        local amount, overkill
        if kind == "SWING_DAMAGE" then amount, overkill = arg9, arg10
        elseif kind == "ENVIRONMENTAL_DAMAGE" then amount, overkill = arg10, arg11
        else amount, overkill = arg12, arg13 end
        if type(amount) == "number" and amount > 0 then
            if type(overkill) == "number" and overkill > 0 then amount = math.max(0, amount - overkill) end
            fears[destGUID].damage = fears[destGUID].damage + amount
        end
    end
end

function me.DrawFear(data, meta, visible, now)
    local cfg = me.Profile.fear
    local text = data.fearText
    text:SetFont(STANDARD_TEXT_FONT, cfg.size, "OUTLINE")
    text:ClearAllPoints()
    text:SetPoint("TOP", data.health or data.visual, "BOTTOM", cfg.x, cfg.y)
    text:SetTextColor(1, 0.9, 0.1)
    local record
    for guid, fear in pairs(fears) do
        if now >= fear.expires then fears[guid] = nil
        elseif meta and meta.guid == guid then record = fear
        elseif not meta and fear.name == data.name:GetText() then
            if record then record = false; break end
            record = fear
        end
    end
    if cfg.enabled and visible and record then
        if meta and not record.known and meta.maxHP > 0 then
            record.maxHP, record.known = meta.maxHP, true
        end
        local remaining = math.max(0, record.maxHP * cfg.threshold / 100 - record.damage)
        text:SetFormattedText("%.0f", remaining)
        text:Show()
    else text:Hide() end
end

function me.InitializeFear()
    frame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
    frame:RegisterEvent("PLAYER_ENTERING_WORLD")
    frame:SetScript("OnEvent", me.FearOnEvent)
end
