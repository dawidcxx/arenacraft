local ADDON, me = ...

-- Clickable area of a nameplate = the native WorldFrame child (only it can target).
-- The client positions it every frame, so it is never moved with SetPoint.
-- Instead it is pinned with SetClampedToScreen + SetClampRectInsets, which the
-- client honours on protected plates in combat too (RefinedBlizzPlates stacking
-- uses the same mechanism). SetSize is protected: sizes change out of combat only.
-- The visual part is positioned from the engine anchor, not from the moved plate.

local SLACK = 2 -- screen units of tolerance, keeps the clamp rect smaller than the screen
local warnedAnchor, clampBlocked

local function Fraction(point)
    local fx = point:find("LEFT", 1, true) and 0 or (point:find("RIGHT", 1, true) and 1 or 0.5)
    local fy = point:find("BOTTOM", 1, true) and 0 or (point:find("TOP", 1, true) and 1 or 0.5)
    return fx, fy
end

--- Engine anchor of the native plate in plate units: x, y and the anchored fraction of the plate.
local function NativeAnchor(plate, ps)
    if plate:GetNumPoints() ~= 1 then return end
    local point, rel, relPoint, x, y = plate:GetPoint(1)
    if not point then return end
    rel = rel or me.Frame.GetParent(plate)
    local rl, rb = rel:GetLeft(), rel:GetBottom()
    if not rl or not rb then return end
    local rs = rel:GetEffectiveScale() / ps
    local rfx, rfy = Fraction(relPoint or point)
    local fx, fy = Fraction(point)
    return (rl + rel:GetWidth() * rfx) * rs + (x or 0), (rb + rel:GetHeight() * rfy) * rs + (y or 0), fx, fy
end

local function Rect(region, ps)
    local l, b = region:GetLeft(), region:GetBottom()
    if not l or not b then return end
    local s = region:GetEffectiveScale() / ps
    return l * s, b * s, (l + region:GetWidth()) * s, (b + region:GetHeight()) * s
end

--- Bounds of what the player should be able to click, in plate units.
local function TargetRect(data, ps)
    local style, icon = data.totemStyle, data.totemIcon
    local iconShown = icon and style and style.icon and icon:IsShown()
    if iconShown and style.iconOnly then return Rect(icon, ps) end
    local l, b, r, t = Rect(data.visual, ps)
    if l and iconShown then
        local il, ib, ir, it = Rect(icon, ps)
        if il then
            l, b, r, t = math.min(l, il), math.min(b, ib), math.max(r, ir), math.max(t, it)
        end
    end
    return l, b, r, t
end

local function Pin(plate, data, left, bottom, width, height, ps)
    if clampBlocked and InCombatLockdown() then return end
    local s = UIParent:GetEffectiveScale() / ps
    local sw, sh = GetScreenWidth() * s - SLACK, GetScreenHeight() * s - SLACK
    -- Clamp rect = plate rect shifted by (-left, -bottom) and stretched to almost the
    -- screen size: the only allowed plate position is (left, bottom) +- SLACK.
    plate:SetClampRectInsets(-left, sw - left - width, sh - bottom - height, -bottom)
    if not data.clamped then
        plate:SetClampedToScreen(true)
        data.clamped = true
    end
end

function me.ReleaseClickZone(plate)
    local data = me.PlateData[plate]
    if data and data.clamped and not (clampBlocked and InCombatLockdown()) then
        plate:SetClampedToScreen(false)
        data.clamped = nil
    end
end

local function Fallback(plate, data, visual)
    if not warnedAnchor then
        warnedAnchor = true
        print("heckfyplates: native nameplate anchor unavailable; click zone stays at the native position.")
    end
    me.ReleaseClickZone(plate)
    visual:ClearAllPoints()
    visual:SetPoint("TOP", plate, "TOP", 0, me.OptionsCharacter.VerticalOffset)
    data.clickAnchor = nil
end

--- Places the visual part and moves/resizes the native click zone under it.
function me.UpdateClickZone(plate)
    local data = me.PlateData[plate]
    if not data or not plate:IsShown() then return end
    local visual = data.visual
    local ps = plate:GetEffectiveScale()
    local ax, ay, fx, fy = NativeAnchor(plate, ps)
    if not ax then return Fallback(plate, data, visual) end

    -- Where the unmodified plate (sized like the visual) would draw the visual,
    -- plus the configured vertical offset.
    local ratio = visual:GetEffectiveScale() / ps
    local vw, vh = visual:GetWidth() * ratio, visual:GetHeight() * ratio
    local vcx = ax - vw * fx + vw / 2
    local vtop = ay - vh * fy + vh + me.OptionsCharacter.VerticalOffset * ratio

    -- Target bounds are measured relative to the visual's current top-centre,
    -- so they do not depend on where the clamped plate sits this frame.
    local vl, _, vr, vt = Rect(visual, ps)
    local tl, tb, tr, tt = TargetRect(data, ps)
    if not vl or not tl then return end
    local dx, dy = vcx - (vl + vr) / 2, vtop - vt
    tl, tr, tb, tt = tl + dx, tr + dx, tb + dy, tt + dy

    if not InCombatLockdown() then
        local tw, th = math.max(1, tr - tl), math.max(1, tt - tb)
        if math.abs(plate:GetWidth() - tw) > 0.05 or math.abs(plate:GetHeight() - th) > 0.05 then
            plate:SetWidth(tw)
            plate:SetHeight(th)
        end
    end
    -- In combat the size is frozen: centre whatever size the plate has on the target.
    local w, h = plate:GetWidth(), plate:GetHeight()
    local left, bottom = (tl + tr - w) / 2, (tb + tt - h) / 2
    if data.filtered or data.distanceHidden then
        -- Hidden by filters or the distance limit: park the click zone far below the screen.
        bottom = -(GetScreenHeight() * UIParent:GetEffectiveScale() / ps) * 3 - h
    end
    Pin(plate, data, left, bottom, w, h, ps)

    -- Anchored to an absolute position, so the clamp tolerance never shakes the visual.
    if not data.clickAnchor then
        visual:ClearAllPoints()
        data.clickAnchor = true
    end
    local ws = WorldFrame:GetEffectiveScale()
    local wl, wb = WorldFrame:GetLeft() or 0, WorldFrame:GetBottom() or 0
    local vs = visual:GetEffectiveScale()
    visual:SetPoint("TOP", WorldFrame, "BOTTOMLEFT", (vcx * ps - wl * ws) / vs, (vtop * ps - wb * ws) / vs)
    if me.ShowClickZones and not data.clickDebug then me.UpdateClickDebug(plate, data) end
end

function me.InitializeClickZone()
    local events = CreateFrame("Frame")
    events:RegisterEvent("ADDON_ACTION_BLOCKED")
    events:RegisterEvent("ADDON_ACTION_FORBIDDEN")
    events:SetScript("OnEvent", function(_, event, addon, action)
        if addon ~= ADDON then return end
        action = tostring(action)
        if action:find("Clamp", 1, true) and not clampBlocked then
            clampBlocked = true
            print("heckfyplates: the client blocked " .. action .. " in combat; click zones will follow again after combat.")
        elseif me.LastBlockedFunction ~= action then
            me.LastBlockedFunction = action
            print("heckfyplates: " .. event .. " " .. action)
        end
    end)
end

-- Debug: /hpdebug shows the real native click zones as red boxes.
function me.UpdateClickDebug(plate, data)
    if me.ShowClickZones and not data.clickDebug then
        data.clickDebug = plate:CreateTexture(nil, "OVERLAY")
        data.clickDebug:SetTexture(1, 0, 0, 0.35)
        data.clickDebug:SetAllPoints(plate)
    end
    if data.clickDebug then
        if me.ShowClickZones then data.clickDebug:Show() else data.clickDebug:Hide() end
    end
end

SLASH_HECKFYPLATESCLICKDEBUG1 = "/hpdebug"
SlashCmdList.HECKFYPLATESCLICKDEBUG = function()
    me.ShowClickZones = not me.ShowClickZones
    for plate, data in pairs(me.PlateData) do me.UpdateClickDebug(plate, data) end
    print("heckfyplates: click zone debug " .. (me.ShowClickZones and "on" or "off"))
end
