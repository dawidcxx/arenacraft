local _, me = ...
local ru = GetLocale() == "ruRU"
local controls, refreshing = {}, false
local serial = 0

local function L(russian, english)
    return ru and russian or english
end

local function Text(parent, value, x, y, template)
    local text = parent:CreateFontString(nil, "ARTWORK", template or "GameFontHighlight")
    text:SetPoint("TOPLEFT", x, y)
    text:SetText(value)
    return text
end

local function Panel(name, parent)
    local panel = CreateFrame("Frame", nil, UIParent)
    panel.name, panel.parent = name, parent
    Text(panel, name, 16, -16, "GameFontNormalLarge")
    panel:SetScript("OnShow", function() if me.RefreshConfig then me.RefreshConfig() end end)
    panel:Hide()
    InterfaceOptions_AddCategory(panel)
    return panel
end

local function ScrollPanel(name, parent, suffix, height)
    local panel = Panel(name, parent)
    local scroll = CreateFrame("ScrollFrame", "HeckfyplatesSettingsScroll" .. suffix, panel, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 18, -45)
    scroll:SetPoint("BOTTOMRIGHT", -40, 16)
    local body = CreateFrame("Frame", nil, scroll)
    body:SetWidth(430)
    body:SetHeight(height)
    scroll:SetScrollChild(body)
    return body
end

local function Button(parent, label, x, y, width, action)
    local button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    button:SetPoint("TOPLEFT", x, y)
    button:SetWidth(width)
    button:SetHeight(24)
    button:SetText(label)
    button:SetScript("OnClick", action)
    return button
end

local function Edit(parent, x, y, width)
    serial = serial + 1
    local box = CreateFrame("EditBox", "HeckfyplatesEdit" .. serial, parent)
    box:SetPoint("TOPLEFT", x, y)
    box:SetWidth(width)
    box:SetHeight(24)
    box:SetFontObject(GameFontHighlightSmall)
    box:SetTextInsets(8, 8, 0, 0)
    box:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 12,
        insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    box:SetBackdropColor(0.04, 0.04, 0.04, 0.95)
    box:SetBackdropBorderColor(0.55, 0.55, 0.55, 1)
    box:EnableMouse(true)
    box:SetAutoFocus(false)
    box:SetMaxLetters(60)
    box:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    box:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    return box
end

local function Enabled(control, enabled)
    control:SetAlpha(enabled and 1 or 0.45)
    if control.kind == "menu" then
        if enabled then UIDropDownMenu_EnableDropDown(control)
        else UIDropDownMenu_DisableDropDown(control) end
    elseif control.kind == "slider" then
        control:EnableMouse(enabled)
        if enabled then BlizzardOptionsPanel_Slider_Enable(control)
        else BlizzardOptionsPanel_Slider_Disable(control) end
    else
        if enabled then control:Enable() else control:Disable() end
    end
end

local function Register(control, getter, castDependent)
    control.getter, control.castDependent = getter, castDependent
    controls[#controls + 1] = control
    return control
end

local function Check(parent, label, x, y, getter, setter, castDependent)
    serial = serial + 1
    local name = "VirtualPlatesUnifiedCheck" .. serial
    local check = CreateFrame("CheckButton", name, parent, "InterfaceOptionsCheckButtonTemplate")
    check:SetPoint("TOPLEFT", x, y)
    _G[name .. "Text"]:SetText(label)
    check:SetScript("OnClick", function(self)
        if refreshing or (castDependent and not me.Profile.cast.enabled) then return end
        setter(self:GetChecked() and true or false)
        me.RefreshAll()
        me.RefreshConfig()
    end)
    return Register(check, getter, castDependent)
end

local function Slider(parent, label, x, y, low, high, step, getter, setter, castDependent)
    serial = serial + 1
    local name = "VirtualPlatesUnifiedSlider" .. serial
    local slider = CreateFrame("Slider", name, parent, "OptionsSliderTemplate")
    slider.kind = "slider"
    slider:SetWidth(190)
    slider:SetPoint("TOPLEFT", x, y)
    slider:SetMinMaxValues(low, high)
    slider:SetValueStep(step)
    _G[name .. "Low"]:SetText(low)
    _G[name .. "High"]:SetText(high)
    slider.label, slider.step = label, step
    slider:SetScript("OnValueChanged", function(self, value)
        value = math.floor(value / step + 0.5) * step
        _G[name .. "Text"]:SetFormattedText(step < 1 and "%s: %.2f" or "%s: %.0f", label, value)
        if refreshing or (castDependent and not me.Profile.cast.enabled) then return end
        setter(value)
        me.RefreshAll()
        if me.RefreshConfig then me.RefreshConfig() end
    end)
    return Register(slider, getter, castDependent)
end

local function Menu(parent, x, y, width, entries, getter, setter, castDependent)
    serial = serial + 1
    local menu = CreateFrame("Frame", "VirtualPlatesUnifiedMenu" .. serial, parent, "UIDropDownMenuTemplate")
    menu.kind, menu.entries = "menu", entries
    menu:SetPoint("TOPLEFT", x, y)
    UIDropDownMenu_SetWidth(menu, width)
    UIDropDownMenu_Initialize(menu, function()
        local items = type(entries) == "function" and entries() or entries
        for _, entry in ipairs(items) do
            local key, label = entry[1], entry[2]
            local info = UIDropDownMenu_CreateInfo()
            info.text, info.checked = label, getter() == key
            info.func = function()
                if castDependent and not me.Profile.cast.enabled then return end
                setter(key)
                me.RefreshAll()
                me.RefreshConfig()
            end
            UIDropDownMenu_AddButton(info)
        end
    end)
    return Register(menu, getter, castDependent)
end

local rules = {
    { "inherit", L("Общее правило", "Inherit") },
    { "show", L("Показывать", "Show") },
    { "hide", L("Скрывать", "Hide") },
}

local function RuleValue(value)
    if value == nil then return "inherit" end
    return value and "show" or "hide"
end

local function SetRule(target, key, value)
    if value == "inherit" then target[key] = nil
    else target[key] = value == "show" end
end

function me.BuildConfig()
    local root = Panel("heckfyplates")
    me.Config = root
    local active = Text(root, "", 18, -46)
    active:SetWidth(435)
    active:SetHeight(36)
    active:SetJustifyH("LEFT")
    Menu(root, 0, -84, 195, function()
        local names, entries = {}, {}
        for name in pairs(me.DB.profiles) do names[#names + 1] = name end
        table.sort(names)
        for _, name in ipairs(names) do entries[#entries + 1] = { name, name } end
        return entries
    end, function() return me.DB.characters[me.Character] end, me.SelectProfile)
    local nameBox = Edit(root, 252, -87, 193)
    nameBox:SetMaxLetters(32)
    local message = Text(root, "", 18, -154, "GameFontHighlightSmall")
    message:SetWidth(435)
    message:SetJustifyH("LEFT")
    local function Name()
        local name = nameBox:GetText():match("^%s*(.-)%s*$")
        if name == "" then message:SetText(L("Введите имя профиля.", "Enter a profile name.")); return end
        return name
    end
    Button(root, L("Выбрать / создать", "Use / create"), 18, -122, 140, function()
        local name = Name()
        if name then me.SelectProfile(name); message:SetText("") end
    end)
    Button(root, L("Копировать в новый", "Copy to new"), 170, -122, 140, function()
        local name = Name()
        if not name then return end
        if me.DB.profiles[name] then
            message:SetText(L("Такой профиль уже существует.", "That profile already exists."))
            return
        end
        me.DB.profiles[name] = me.Copy(me.Profile)
        me.SelectProfile(name)
        message:SetText("")
    end)
    Button(root, L("Сбросить", "Reset"), 322, -122, 124, function()
        local name = me.DB.characters[me.Character]
        me.DB.profiles[name] = me.Copy(me.Defaults)
        me.SelectProfile(name)
    end)
    Text(root, L("Неймплейты: размер и положение", "Nameplates: scale and position"), 18, -183, "GameFontNormal")
    root.ScaleFactor = Slider(root, L("Дистанция масштаба 1", "Scale factor"), 22, -223, 5, 40, 1,
        function() return me.OptionsCharacter.ScaleFactor end,
        function(v) me.OptionsCharacter.ScaleFactor = v end)
    root.VerticalOffset = Slider(root, L("Смещение вверх", "Vertical offset"), 260, -223, -100, 100, 1,
        function() return me.OptionsCharacter.VerticalOffset end,
        function(v) me.OptionsCharacter.VerticalOffset = v end)
    root.MinScale = Slider(root, L("Минимальный масштаб", "Minimum scale"), 22, -286, 0, 1, 0.05,
        function() return me.OptionsCharacter.MinScale end, function(v)
            me.OptionsCharacter.MinScale = v
            me.OptionsCharacter.MaxScale = math.max(v, me.OptionsCharacter.MaxScale)
        end)
    root.MaxScale = Slider(root, L("Максимальный масштаб", "Maximum scale"), 260, -286, 0.1, 10, 0.05,
        function() return me.OptionsCharacter.MaxScale end,
        function(v) me.OptionsCharacter.MaxScale = math.max(v, me.OptionsCharacter.MinScale) end)
    root.MaxScaleEnabled = Check(root, L("Ограничивать максимальный масштаб", "Limit maximum scale"), 18, -337,
        function() return me.OptionsCharacter.MaxScaleEnabled end,
        function(v) me.OptionsCharacter.MaxScaleEnabled = v end)
    root.MaxScaleEnabled.setFunc = function(value) me.OptionsCharacter.MaxScaleEnabled = value == "1"; me.RefreshConfig() end
    local distanceLabel = L("Макс. дистанция, ярды (0 = без лимита)", "Max distance, yards (0 = no limit)")
    Slider(root, distanceLabel, 22, -392, 0, 100, 1,
        function() return me.Profile.maxDistance end,
        function(v) me.Profile.maxDistance = v end)
    local distanceBox = Edit(root, 260, -386, 70)
    distanceBox:SetMaxLetters(3)
    distanceBox.kind = "edit"
    distanceBox:SetScript("OnEnterPressed", function(self)
        local value = tonumber(self:GetText())
        if value then me.Profile.maxDistance = math.floor(math.max(0, math.min(100, value)) + 0.5) end
        self:ClearFocus()
        me.RefreshAll()
        me.RefreshConfig()
    end)
    distanceBox:SetScript("OnEditFocusLost", function() me.RefreshConfig() end)
    Register(distanceBox, function() return me.Profile.maxDistance end)
    local distanceHint = Text(root, L("Только уменьшает дальность клиента; считается от камеры.",
        "Only shortens the client range; measured from the camera."), 18, -430, "GameFontHighlightSmall")
    distanceHint:SetWidth(435)
    distanceHint:SetJustifyH("LEFT")
    local combatStatus = Text(root, "", 18, -452, "GameFontHighlightSmall")
    combatStatus:SetWidth(435)
    combatStatus:SetJustifyH("LEFT")

    local cast = Panel(L("Кастбары", "Cast bars"), root.name)
    me.CastPanel = cast
    Check(cast, L("Кастбары под неймплейтами", "Cast bars under nameplates"), 18, -47,
        function() return me.Profile.cast.enabled end,
        function(v) me.Profile.cast.enabled = v end)
    for _, entry in ipairs({ { "width", L("Ширина", "Width"), 40, 400, 22, -112 },
        { "height", L("Высота", "Height"), 4, 50, 260, -112 },
        { "x", L("Смещение X", "Offset X"), -200, 200, 22, -176 },
        { "y", L("Смещение Y", "Offset Y"), -200, 200, 260, -176 } }) do
        local key = entry[1]
        Slider(cast, entry[2], entry[5], entry[6], entry[3], entry[4], 1,
            function() return me.Profile.cast[key] end,
            function(v) me.Profile.cast[key] = v end, true)
    end
    local appearanceLabel = Text(cast, L("Оформление", "Appearance"), 22, -224, "GameFontNormal")
    Menu(cast, 0, -246, 195, {
        { "Native", L("Как в патче (встроенное)", "Patch / native") },
        { "Blizzard", L("Blizzard: заполнение", "Blizzard fill") },
        { "LiteStep", "LiteStep" }, { "Flat", L("Плоская", "Flat") }, { "Skills", "Skills" },
    }, function() return me.Profile.cast.texture end,
        function(v) me.Profile.cast.texture = v end, true)
    local timerLabel = Text(cast, L("Формат таймера", "Timer format"), 260, -224, "GameFontNormal")
    Menu(cast, 238, -246, 195, {
        { "LEFT", L("Остаток", "Remaining") }, { "TOTAL", L("Длительность", "Total") },
        { "BOTH", L("Остаток / всего", "Remaining / total") },
    }, function() return me.Profile.cast.timerFormat end,
        function(v) me.Profile.cast.timerFormat = v end, true)
    for index, entry in ipairs({ { "icon", L("Иконка", "Icon") },
        { "spell", L("Название заклинания", "Spell name") }, { "timer", L("Таймер", "Timer") } }) do
        local key = entry[1]
        Check(cast, entry[2], 18 + ((index - 1) % 2) * 238, -304 - math.floor((index - 1) / 2) * 34,
            function() return me.Profile.cast[key] end,
            function(v) me.Profile.cast[key] = v end, true)
    end
    me.Preview = me.CreateCastBar(cast)
    me.Preview:SetPoint("CENTER", cast, "BOTTOM", 0, 65)
    cast:SetScript("OnHide", function() me.Preview:Hide() end)

    local filters = Panel(L("Фильтры неймплейтов", "Nameplate filters"), root.name)
    for index, entry in ipairs({ { "players", L("Игроки", "Players") },
        { "npcs", L("Обычные NPC", "Other NPCs") }, { "pets", L("Питомцы", "Pets") },
        { "minions", L("Прислужники", "Minions") } }) do
        local key = entry[1]
        Check(filters, entry[2], 18 + ((index - 1) % 2) * 238, -45 - math.floor((index - 1) / 2) * 30,
            function() return me.Profile.filters[key] end,
            function(v) me.Profile.filters[key] = v end)
    end
    local scroll = CreateFrame("ScrollFrame", "VirtualPlatesFilterScroll", filters, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 18, -153)
    scroll:SetPoint("BOTTOMRIGHT", -40, 16)
    local body = CreateFrame("Frame", nil, scroll)
    body:SetWidth(430)
    local filterCount = 0
    for _, entry in ipairs(me.FilterEntries) do
        if entry[2] ~= "totems" then filterCount = filterCount + 1 end
    end
    body:SetHeight(filterCount * 40)
    scroll:SetScrollChild(body)
    local row = 0
    for _, entry in ipairs(me.FilterEntries) do
        if entry[2] ~= "totems" then
        row = row + 1
        local key = entry[1]
        local label = Text(body, ru and entry[5] or entry[4], 0, -(row - 1) * 40 - 7, "GameFontHighlightSmall")
        label:SetWidth(220)
        label:SetHeight(30)
        label:SetJustifyH("LEFT")
        Menu(body, 230, -(row - 1) * 40, 155, rules,
            function() return RuleValue(me.Profile.filters.overrides[key]) end,
            function(v) SetRule(me.Profile.filters.overrides, key, v) end)
        end
    end

    local totems = Panel(L("Тотемы", "Totems"), root.name)
    Check(totems, L("Показывать тотемы по умолчанию", "Show totems by default"), 18, -45,
        function() return me.Profile.filters.totems end,
        function(v) me.Profile.filters.totems = v end)
    local totemAppearance = Panel(L("Вид тотемов", "Totem appearance"), root.name)
    local appearanceScroll = CreateFrame("ScrollFrame", "HeckfyplatesTotemAppearanceScroll", totemAppearance, "UIPanelScrollFrameTemplate")
    appearanceScroll:SetPoint("TOPLEFT", 18, -45)
    appearanceScroll:SetPoint("BOTTOMRIGHT", -40, 16)
    local appearanceBody = CreateFrame("Frame", nil, appearanceScroll)
    appearanceBody:SetWidth(430)
    appearanceBody:SetHeight(250)
    appearanceScroll:SetScrollChild(appearanceBody)
    Check(appearanceBody, L("Иконка тотема", "Totem icon"), 0, 0,
        function() return me.Profile.totem.icon end,
        function(v)
            me.Profile.totem.icon = v
            if not v then me.Profile.totem.iconOnly = false end
        end)
    Check(appearanceBody, L("Только иконка вместо неймплейта", "Icon only"), 0, -31,
        function() return me.Profile.totem.iconOnly end,
        function(v)
            me.Profile.totem.iconOnly = v
            if v then me.Profile.totem.icon = true end
        end)
    for _, entry in ipairs({
        { "size", L("Размер иконки", "Icon size"), 8, 80, 1, 4, -81 },
        { "plateAlpha", L("Прозрачность неймплейта", "Plate opacity"), 0, 1, 0.05, 224, -81 },
        { "x", L("Смещение иконки X", "Icon offset X"), -100, 100, 1, 4, -141 },
        { "y", L("Смещение иконки Y", "Icon offset Y"), -100, 100, 1, 224, -141 },
        { "iconAlpha", L("Прозрачность иконки", "Icon opacity"), 0, 1, 0.05, 4, -201 },
    }) do
        local key = entry[1]
        local control = Slider(appearanceBody, entry[2], entry[6], entry[7], entry[3], entry[4], entry[5],
            function() return me.Profile.totem[key] end,
            function(v) me.Profile.totem[key] = v end)
        if key == "x" or key == "y" then
        end
    end
    local tickBody = ScrollPanel(L("Тики тотемов", "Totem ticks"), root.name, "TotemTicks", 610)
    Text(tickBody, L("Отображение тиков", "Tick display"), 4, 0, "GameFontNormal")
    Menu(tickBody, -18, -22, 230, {
        { "OFF", L("Выключено", "Off") },
        { "TEXT", L("Только таймер", "Timer only") },
        { "VERTICAL", L("Сверху вниз", "Top to bottom") },
        { "RADIAL", L("Круговая анимация", "Circular animation") },
        { "TEXT_VERTICAL", L("Таймер + сверху вниз", "Timer + top to bottom") },
        { "TEXT_RADIAL", L("Таймер + круг", "Timer + circular") },
    }, function() return me.Profile.totemTicks.mode end,
        function(v) me.Profile.totemTicks.mode = v end)
    for _, entry in ipairs({
        { "opacity", L("Затемнение", "Shading opacity"), 0, 1, 0.05, 4, -85 },
        { "size", L("Размер таймера", "Timer font size"), 7, 24, 1, 224, -85 },
        { "x", L("Таймер X", "Timer X"), -40, 40, 1, 4, -145 },
        { "y", L("Таймер Y", "Timer Y"), -40, 40, 1, 224, -145 },
    }) do
        local key = entry[1]
        local control = Slider(tickBody, entry[2], entry[6], entry[7], entry[3], entry[4], entry[5],
            function() return me.Profile.totemTicks[key] end,
            function(v) me.Profile.totemTicks[key] = v end)
        control.enabledWhen = function() return me.Profile.totemTicks.mode ~= "OFF" end
    end
    Text(tickBody, L("Интервал тиков (сек.)", "Tick interval (sec.)"), 4, -207, "GameFontNormal")
    local tickCount = 0
    for _, entry in ipairs(me.FilterEntries) do
        local key = entry[1]
        if me.Defaults.totemTicks.intervals[key] then
            local column, row = tickCount % 2, math.floor(tickCount / 2)
            local control = Slider(tickBody, ru and entry[5] or entry[4],
                4 + column * 220, -245 - row * 70, 0.5, 15, 0.1,
                function() return me.Profile.totemTicks.intervals[key] end,
                function(v) me.Profile.totemTicks.intervals[key] = v end)
            control.enabledWhen = function() return me.Profile.totemTicks.mode ~= "OFF" end
            tickCount = tickCount + 1
        end
    end
    local function AllTotems(value)
        for _, entry in ipairs(me.FilterEntries) do
            if entry[2] == "totems" then me.Profile.filters.overrides[entry[1]] = value end
        end
        me.RefreshAll()
        me.RefreshConfig()
    end
    Button(totems, L("Все вкл.", "All on"), 260, -45, 90, function() AllTotems(true) end)
    Button(totems, L("Все выкл.", "All off"), 358, -45, 90, function() AllTotems(false) end)
    local totemScroll = CreateFrame("ScrollFrame", "HeckfyplatesTotemScroll", totems, "UIPanelScrollFrameTemplate")
    totemScroll:SetPoint("TOPLEFT", 18, -90)
    totemScroll:SetPoint("BOTTOMRIGHT", -40, 16)
    local totemBody = CreateFrame("Frame", nil, totemScroll)
    totemBody:SetWidth(430)
    local totemCount = 0
    for _, entry in ipairs(me.FilterEntries) do
        if entry[2] == "totems" then
            local key = entry[1]
            local check = Check(totemBody, ru and entry[5] or entry[4], 0, -totemCount * 30,
                function()
                    local value = me.Profile.filters.overrides[key]
                    if value == nil then return me.Profile.filters.totems end
                    return value
                end,
                function(v) me.Profile.filters.overrides[key] = v end)
            check.tooltipText = L("Показывать этот вид тотема.", "Show this totem type.")
            totemCount = totemCount + 1
        end
    end
    totemBody:SetHeight(totemCount * 30)
    totemScroll:SetScrollChild(totemBody)

    local healthBody = ScrollPanel(L("HP и имя", "HP and name"), root.name, "Health", 690)
    Check(healthBody, L("Дружественным целям - стандартные цвета", "Default colors for friendly targets"), 0, -340,
        function() return me.Profile.names.keepFriendlyDefault end,
        function(v) me.Profile.names.keepFriendlyDefault = v end)
    Check(healthBody, L("Запоминать максимум HP цели", "Remember target maximum HP"), 0, -305,
        function() return me.Profile.healthText.remember end,
        function(v) me.Profile.healthText.remember = v end)
    Check(healthBody, L("Полоса здоровья по цвету класса", "Health bar in class color"), 0, -270,
        function() return me.Profile.names.healthClassColor end,
        function(v) me.Profile.names.healthClassColor = v end)
    Check(healthBody, L("Цвет имени игрока по классу", "Player name in class color"), 0, 0,
        function() return me.Profile.names.classColor end,
        function(v) me.Profile.names.classColor = v end)
    Check(healthBody, L("HP на полосе здоровья", "Health text on the bar"), 0, -34,
        function() return me.Profile.healthText.enabled end,
        function(v) me.Profile.healthText.enabled = v end)
    Text(healthBody, L("Формат HP", "HP format"), 4, -76, "GameFontNormal")
    local healthMenu = Menu(healthBody, -18, -94, 195, {
        { "CURRENT", "12000" }, { "CURRENT_MAX", "12000 / 20000" },
        { "PERCENT", "60%" }, { "CURRENT_PERCENT", "12000 (60%)" },
        { "CURRENT_MAX_PERCENT", "12000 / 20000 (60%)" }, { "MISSING", "-8000" },
    }, function() return me.Profile.healthText.format end,
        function(v) me.Profile.healthText.format = v end)
    healthMenu.enabledWhen = function() return me.Profile.healthText.enabled end
    for _, entry in ipairs({ { "size", L("Размер текста", "Font size"), 7, 24, 4, -150 },
        { "x", L("Смещение X", "Offset X"), -200, 200, 224, -150 },
        { "y", L("Смещение Y", "Offset Y"), -200, 200, 4, -210 } }) do
        local key = entry[1]
        local control = Slider(healthBody, entry[2], entry[5], entry[6], entry[3], entry[4], 1,
            function() return me.Profile.healthText[key] end,
            function(v) me.Profile.healthText[key] = v end)
        control.enabledWhen = function() return me.Profile.healthText.enabled end
    end

    Text(healthBody, L("Подпись игрока", "Player label"), 4, -385, "GameFontNormal")
    Check(healthBody, L("Название класса вместо имени", "Class name instead of the name"), 0, -405,
        function() return me.Profile.labels.className end,
        function(v) me.Profile.labels.className = v end)
    Check(healthBody, L("Номер арены (arena1-5)", "Arena number (arena1-5)"), 0, -435,
        function() return me.Profile.labels.arena end,
        function(v) me.Profile.labels.arena = v end)
    local arenaOn = function() return me.Profile.labels.arena end
    local numberOnly = Check(healthBody, L("Только номер, без имени/класса", "Number only, no name/class"), 0, -465,
        function() return me.Profile.labels.arenaNumberOnly end,
        function(v) me.Profile.labels.arenaNumberOnly = v end)
    numberOnly.enabledWhen = arenaOn
    Text(healthBody, L("Положение номера", "Number position"), 4, -505, "GameFontNormal")
    local modeMenu = Menu(healthBody, -18, -523, 195, {
        { "STACK", L("Рядом с именем (ник 1)", "Stack to name (name 1)") },
        { "STANDALONE", L("Отдельно (двигать X/Y)", "Standalone (move X/Y)") },
    }, function() return me.Profile.labels.arenaMode end,
        function(v) me.Profile.labels.arenaMode = v end)
    modeMenu.enabledWhen = arenaOn
    for _, entry in ipairs({ { "arenaSize", L("Размер номера", "Number size"), 7, 32, 4, -580 },
        { "arenaX", L("Номер X", "Number X"), -200, 200, 224, -580 },
        { "arenaY", L("Номер Y", "Number Y"), -200, 200, 4, -640 } }) do
        local key = entry[1]
        local control = Slider(healthBody, entry[2], entry[5], entry[6], entry[3], entry[4], 1,
            function() return me.Profile.labels[key] end,
            function(v) me.Profile.labels[key] = v end)
        control.enabledWhen = function()
            return me.Profile.labels.arena and me.Profile.labels.arenaMode == "STANDALONE"
        end
    end

    local combatBody = ScrollPanel(L("Комбат-трекер", "Combat tracker"), root.name, "Combat", 280)
    Check(combatBody, L("Иконка статуса боя", "Combat status icon"), 0, 0,
        function() return me.Profile.combatText.enabled end,
        function(v) me.Profile.combatText.enabled = v end)
    local showOut = Check(combatBody, L("Серая иконка вне боя", "Gray icon out of combat"), 0, -34,
        function() return me.Profile.combatText.showOut end,
        function(v) me.Profile.combatText.showOut = v end)
    showOut.enabledWhen = function() return me.Profile.combatText.enabled end
    Text(combatBody, L("Значок", "Icon"), 4, -76, "GameFontNormal")
    local combatMenu = Menu(combatBody, -18, -94, 195, {
        { "SWORDS", L("Скрещенное оружие", "Crossed weapons") },
        { "ROLE", L("Значок роли урона", "Damage role") },
        { "DUAL", L("Два оружия", "Dual wield") },
    }, function() return me.Profile.combatText.icon end,
        function(v) me.Profile.combatText.icon = v end)
    combatMenu.enabledWhen = function() return me.Profile.combatText.enabled end
    for _, entry in ipairs({ { "size", L("Размер иконки", "Icon size"), 8, 48, 4, -150 },
        { "x", L("Смещение X", "Offset X"), -200, 200, 224, -150 },
        { "y", L("Смещение Y", "Offset Y"), -200, 200, 4, -210 } }) do
        local key = entry[1]
        local control = Slider(combatBody, entry[2], entry[5], entry[6], entry[3], entry[4], 1,
            function() return me.Profile.combatText[key] end,
            function(v) me.Profile.combatText[key] = v end)
        control.enabledWhen = function() return me.Profile.combatText.enabled end
    end

    local fearBody = ScrollPanel(L("Порог фира", "Fear threshold"), root.name, "Fear", 275)
    Check(fearBody, L("Остаток урона для Psychic Scream", "Psychic Scream damage budget"), 0, 0,
        function() return me.Profile.fear.enabled end,
        function(v) me.Profile.fear.enabled = v end)
    for _, entry in ipairs({ { "size", L("Размер текста", "Font size"), 7, 24, 1, 4, -76 },
        { "threshold", L("Расчетный порог, % HP", "Estimated threshold, % HP"), 1, 30, 1, 224, -76 },
        { "x", L("Смещение X", "Offset X"), -200, 200, 1, 4, -136 },
        { "y", L("Смещение Y", "Offset Y"), -200, 200, 1, 224, -136 },
        { "fallbackHP", L("HP неизвестной цели", "Unknown unit max HP"), 1000, 100000, 1000, 4, -196 } }) do
        local key = entry[1]
        local control = Slider(fearBody, entry[2], entry[6], entry[7], entry[3], entry[4], entry[5],
            function() return me.Profile.fear[key] end,
            function(v) me.Profile.fear[key] = v end)
        control.enabledWhen = function() return me.Profile.fear.enabled end
    end

    local gcdBody = ScrollPanel(L("GCD противников", "Enemy GCD"), root.name, "GCD", 340)
    Check(gcdBody, L("GCD противников на неймплейтах", "Enemy GCD on nameplates"), 0, 0,
        function() return me.Profile.gcd.enabled end,
        function(v) me.Profile.gcd.enabled = v end)
    local gcdChecks = {
        Check(gcdBody, L("Только арена 1v1 / 2v2", "Arena 1v1 / 2v2 only"), 0, -30,
            function() return me.Profile.gcd.arenaOnly end,
            function(v) me.Profile.gcd.arenaOnly = v end),
        Check(gcdBody, L("Таймер на иконке", "Timer on the icon"), 0, -60,
            function() return me.Profile.gcd.timer end,
            function(v) me.Profile.gcd.timer = v end),
    }
    for _, control in ipairs(gcdChecks) do
        control.enabledWhen = function() return me.Profile.gcd.enabled end
    end
    for _, entry in ipairs({
        { "size", L("Размер иконки", "Icon size"), 10, 64, 1, 4, -115 },
        { "shade", L("Затемнение", "Shading opacity"), 0, 1, 0.05, 224, -115 },
        { "x", L("Смещение X", "Offset X"), -200, 200, 1, 4, -175 },
        { "y", L("Смещение Y", "Offset Y"), -200, 200, 1, 224, -175 },
        { "timerSize", L("Размер таймера", "Timer font size"), 7, 24, 1, 4, -235 },
        { "casterGCD", L("GCD кастеров (с хастой), сек", "Caster GCD (with haste), sec"), 1, 1.5, 0.05, 224, -235 },
    }) do
        local key = entry[1]
        local control = Slider(gcdBody, entry[2], entry[6], entry[7], entry[3], entry[4], entry[5],
            function() return me.Profile.gcd[key] end,
            function(v) me.Profile.gcd[key] = v end)
        control.enabledWhen = function() return me.Profile.gcd.enabled end
    end
    local gcdHint = Text(gcdBody, L("GCD кастеров: жрец, маг, чернокнижник, шаман (не тотемы).",
        "Caster GCD: priest, mage, warlock, shaman (not totems)."), 4, -290, "GameFontHighlightSmall")
    gcdHint:SetWidth(420)
    gcdHint:SetJustifyH("LEFT")

    function me.RefreshConfig()
        if not me.Profile then return end
        refreshing = true
        active:SetText(L("Персонаж: ", "Character: ") .. me.Character .. "\n" ..
            L("Профиль: ", "Profile: ") .. me.DB.characters[me.Character])
        for _, control in ipairs(controls) do
            local value = control.getter()
            if control.kind == "menu" then
                local entries = type(control.entries) == "function" and control.entries() or control.entries
                local text = "-"
                for _, entry in ipairs(entries) do if entry[1] == value then text = entry[2] end end
                UIDropDownMenu_SetText(control, text)
            elseif control.kind == "edit" then
                if not control:HasFocus() then control:SetText(tostring(value)) end
            elseif control.kind == "slider" then
                control:SetValue(value)
                _G[control:GetName() .. "Text"]:SetFormattedText(control.step < 1 and "%s: %.2f" or "%s: %.0f", control.label, value)
            else control:SetChecked(value) end
            if control.castDependent then Enabled(control, me.Profile.cast.enabled) end
            if control.enabledWhen then Enabled(control, control.enabledWhen()) end
        end
        Enabled(root.MaxScale, me.OptionsCharacter.MaxScaleEnabled)
        me.StyleCastBar(me.Preview)
        local color = me.Profile.cast.enabled and 1 or 0.5
        appearanceLabel:SetTextColor(color, color, color)
        timerLabel:SetTextColor(color, color, color)
        if not me.Profile.cast.enabled then me.Preview:Hide() end
        combatStatus:SetText(InCombatLockdown() and L("Размер кликзоны изменится после боя.",
            "Click zone size will change after combat.") or "")
        refreshing = false
    end
    me.RefreshConfig()
    SLASH_VIRTUALPLATESUNIFIED1, SLASH_VIRTUALPLATESUNIFIED2 = "/vp", "/virtualplates"
    SLASH_VIRTUALPLATESUNIFIED3, SLASH_VIRTUALPLATESUNIFIED4 = "/pcb", "/platecastbar"
    SLASH_VIRTUALPLATESUNIFIED5, SLASH_VIRTUALPLATESUNIFIED6 = "/heckfyplates", "/hp"
    SlashCmdList.VIRTUALPLATESUNIFIED = function()
        InterfaceOptionsFrame_OpenToCategory(root)
        InterfaceOptionsFrame_OpenToCategory(root)
    end
end
